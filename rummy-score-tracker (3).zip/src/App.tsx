import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Users, 
  History, 
  Plus, 
  Menu, 
  X, 
  ChevronDown, 
  ChevronUp, 
  Sparkles, 
  PlayCircle,
  Dice5,
  Dices,
  Club
} from 'lucide-react';

import { Player, Match, GameMode } from './types';
import { dbService } from './lib/dbService';

// Import views
import Dashboard from './components/Dashboard';
import PlayersPage from './components/PlayersPage';
import MatchSetup from './components/MatchSetup';
import MatchTable from './components/MatchTable';
import MatchHistoryPage from './components/MatchHistoryPage';

export default function App() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  // Navigation & UI state
  const [activeView, setActiveView] = useState<'dashboard' | 'players' | 'history' | 'setup' | 'table'>('dashboard');
  const [selectedGameMode, setSelectedGameMode] = useState<GameMode>('sevens');
  const [currentMatch, setCurrentMatch] = useState<Match | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isNewMatchMenuOpen, setIsNewMatchMenuOpen] = useState(true); // Open by default in sidebar

  // Load players and matches on mount
  useEffect(() => {
    async function loadData() {
      try {
        const fetchedPlayers = await dbService.getPlayers();
        const fetchedMatches = await dbService.getMatches();
        setPlayers(fetchedPlayers);
        setMatches(fetchedMatches);
      } catch (error) {
        console.error("Error fetching initial data: ", error);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  // Sync state helpers
  const refreshPlayersAndMatches = async () => {
    const fetchedPlayers = await dbService.getPlayers();
    const fetchedMatches = await dbService.getMatches();
    setPlayers(fetchedPlayers);
    setMatches(fetchedMatches);
  };

  // --- ACTIONS ---

  const handleAddPlayer = async (name: string): Promise<boolean> => {
    const newPlayer = await dbService.addPlayer(name);
    if (newPlayer) {
      setPlayers((prev) => [...prev, newPlayer].sort((a, b) => a.name.localeCompare(b.name)));
      return true;
    }
    return false;
  };

  const handleDeletePlayer = async (id: string): Promise<boolean> => {
    const success = await dbService.deletePlayer(id);
    if (success) {
      setPlayers((prev) => prev.filter((p) => p.id !== id));
      return true;
    }
    return false;
  };

  const handleStartSetup = (mode: GameMode) => {
    setSelectedGameMode(mode);
    setActiveView('setup');
    setIsMobileMenuOpen(false);
  };

  const handleStartMatch = async (selectedPlayers: Player[]): Promise<boolean> => {
    const newMatch = await dbService.createMatch(selectedGameMode, selectedPlayers);
    if (newMatch) {
      setMatches((prev) => [newMatch, ...prev]);
      setCurrentMatch(newMatch);
      setActiveView('table');
      return true;
    }
    return false;
  };

  const handleResumeMatch = (match: Match) => {
    setCurrentMatch(match);
    setActiveView('table');
  };

  const handleUpdateMatch = async (updatedMatch: Match): Promise<boolean> => {
    const success = await dbService.updateMatch(updatedMatch);
    if (success) {
      setMatches((prev) => prev.map((m) => (m.id === updatedMatch.id ? updatedMatch : m)));
      setCurrentMatch(updatedMatch);
      return true;
    }
    return false;
  };

  const handleFinishMatch = async (finalizedMatch: Match, winnerId: string, loserId: string): Promise<boolean> => {
    const success = await dbService.updateMatch(finalizedMatch);
    if (success) {
      // Update each player's global statistics (played, won, lost)
      const updatePromises = finalizedMatch.players.map((p) => {
        const isWinner = p.id === winnerId;
        const isLoser = p.id === loserId;
        return dbService.updatePlayerStats(p.id, true, isWinner, isLoser);
      });

      await Promise.all(updatePromises);
      await refreshPlayersAndMatches();
      
      setCurrentMatch(finalizedMatch);
      setActiveView('history'); // Navigate to history to see the concluded record
      return true;
    }
    return false;
  };

  const handleDeleteMatch = async (id: string) => {
    const success = await dbService.deleteMatch(id);
    if (success) {
      setMatches((prev) => prev.filter((m) => m.id !== id));
      if (currentMatch && currentMatch.id === id) {
        setCurrentMatch(null);
        setActiveView('dashboard');
      }
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg flex flex-col md:flex-row text-stone-300 font-sans selection:bg-gold selection:text-black" id="app-root">
      
      {/* Mobile Top Header / Navigation Drawer Bar */}
      <header className="md:hidden bg-dark-sidebar border-b border-stone-800 px-4 py-3 flex items-center justify-between sticky top-0 z-30 shadow-md" id="mobile-header">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-gold/15 flex items-center justify-center text-[#c5a059] border border-gold/30">
            <Club size={18} fill="currentColor" />
          </div>
          <span className="font-serif font-bold text-[#c5a059] tracking-widest text-sm uppercase">Grand Rummy</span>
        </div>

        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-1.5 text-stone-400 hover:text-white hover:bg-stone-800 rounded transition-colors"
          id="mobile-menu-toggle"
        >
          {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </header>

      {/* Mobile Menu Dropdown Panel */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-dark-sidebar border-b border-stone-800 px-4 py-4 space-y-4 absolute top-[53px] w-full z-20 shadow-lg text-stone-300"
            id="mobile-nav-panel"
          >
            <div className="space-y-1.5">
              <button
                onClick={() => { setActiveView('dashboard'); setIsMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-xs font-semibold uppercase tracking-wider transition-colors ${
                  activeView === 'dashboard' ? 'bg-stone-800 text-gold border-l-2 border-gold' : 'text-stone-400 hover:text-white'
                }`}
              >
                <LayoutDashboard size={16} />
                <span>Dashboard</span>
              </button>

              <button
                onClick={() => { setActiveView('players'); setIsMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-xs font-semibold uppercase tracking-wider transition-colors ${
                  activeView === 'players' ? 'bg-stone-800 text-gold border-l-2 border-gold' : 'text-stone-400 hover:text-white'
                }`}
              >
                <Users size={16} />
                <span>Players</span>
              </button>

              <button
                onClick={() => { setActiveView('history'); setIsMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-xs font-semibold uppercase tracking-wider transition-colors ${
                  activeView === 'history' ? 'bg-stone-800 text-gold border-l-2 border-gold' : 'text-stone-400 hover:text-white'
                }`}
              >
                <History size={16} />
                <span>Match History</span>
              </button>
            </div>

            {/* Sub menu: Game Modes */}
            <div className="border-t border-stone-800 pt-3 space-y-2">
              <span className="text-[10px] uppercase font-bold tracking-[0.2em] text-stone-600 px-3 block">
                Play New Match
              </span>
              <div className="grid grid-cols-2 gap-2 px-1">
                <button
                  onClick={() => handleStartSetup('sevens')}
                  className="p-3 bg-stone-900 border border-stone-800 rounded text-xs font-bold flex flex-col items-center gap-1 cursor-pointer hover:border-gold/50 transition-colors"
                >
                  <Sparkles size={14} className="text-gold" />
                  <span className="text-stone-300">Sevens (7s)</span>
                </button>
                <button
                  onClick={() => handleStartSetup('opens')}
                  className="p-3 bg-stone-900 border border-stone-800 rounded text-xs font-bold flex flex-col items-center gap-1 cursor-pointer hover:border-gold/50 transition-colors"
                >
                  <PlayCircle size={14} className="text-gold" />
                  <span className="text-stone-300">Open Joker (320)</span>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop Sidebar Navigation (Left) */}
      <aside className="hidden md:flex flex-col w-64 bg-dark-sidebar border-r border-stone-800 p-6 space-y-8 shrink-0 shadow-xl" id="desktop-sidebar">
        {/* Brand identity */}
        <div className="p-4 border-b border-stone-800/50">
          <h1 className="font-serif text-2xl text-[#c5a059] tracking-widest uppercase">Grand Rummy</h1>
          <p className="text-[9px] uppercase tracking-[0.3em] text-stone-500 mt-1">Elite Scoring Suite</p>
        </div>

        {/* Navigation items */}
        <nav className="flex-1 space-y-6" id="desktop-nav">
          <div className="space-y-1.5">
            <span className="text-[10px] uppercase tracking-[0.2em] text-stone-600 px-4 block mb-2">
              General
            </span>
            
            <button
              onClick={() => setActiveView('dashboard')}
              className={`w-full flex items-center gap-3 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                activeView === 'dashboard' 
                  ? 'bg-stone-800/40 text-white border-l-2 border-[#c5a059]' 
                  : 'text-stone-400 hover:text-[#c5a059]'
              }`}
            >
              <LayoutDashboard size={14} />
              <span>Dashboard</span>
            </button>

            <button
              onClick={() => setActiveView('players')}
              className={`w-full flex items-center gap-3 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                activeView === 'players' 
                  ? 'bg-stone-800/40 text-white border-l-2 border-[#c5a059]' 
                  : 'text-stone-400 hover:text-[#c5a059]'
              }`}
            >
              <Users size={14} />
              <span>Member Directory</span>
            </button>

            <button
              onClick={() => setActiveView('history')}
              className={`w-full flex items-center gap-3 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                activeView === 'history' 
                  ? 'bg-stone-800/40 text-white border-l-2 border-[#c5a059]' 
                  : 'text-stone-400 hover:text-[#c5a059]'
              }`}
            >
              <History size={14} />
              <span>Match History</span>
            </button>
          </div>

          {/* Sub menu: New Match Modes */}
          <div className="space-y-1.5">
            <button
              onClick={() => setIsNewMatchMenuOpen(!isNewMatchMenuOpen)}
              className="w-full flex items-center justify-between px-4 text-stone-600 hover:text-stone-400 cursor-pointer text-left transition-colors"
            >
              <span className="text-[10px] uppercase tracking-[0.2em]">
                New Match Play
              </span>
              {isNewMatchMenuOpen ? <ChevronUp size={10} /> : <ChevronDown size={10} />}
            </button>

            <AnimatePresence initial={false}>
              {isNewMatchMenuOpen && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-1 pl-2"
                >
                  <button
                    onClick={() => handleStartSetup('sevens')}
                    className={`w-full flex items-center gap-2.5 px-4 py-2 text-xs transition-colors cursor-pointer ${
                      activeView === 'setup' && selectedGameMode === 'sevens'
                        ? 'text-gold font-bold'
                        : 'text-stone-400 hover:text-[#c5a059]'
                    }`}
                  >
                    <span className="text-[10px] text-gold">→</span>
                    <span>Sevens Mode</span>
                  </button>

                  <button
                    onClick={() => handleStartSetup('opens')}
                    className={`w-full flex items-center gap-2.5 px-4 py-2 text-xs transition-colors cursor-pointer ${
                      activeView === 'setup' && selectedGameMode === 'opens'
                        ? 'text-gold font-bold'
                        : 'text-stone-400 hover:text-[#c5a059]'
                    }`}
                  >
                    <span className="text-[10px] text-gold">→</span>
                    <span>Open Joker Mode (320 Limit)</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </nav>

        {/* Admin context metadata footer */}
        <div className="p-4 border-t border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-stone-800 border border-stone-700 flex items-center justify-center text-[10px] font-bold text-gold shrink-0">AM</div>
            <div>
              <p className="text-xs font-semibold text-white">Scoring Suite</p>
              <p className="text-[9px] text-stone-500 uppercase tracking-wider">Sync Active</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto" id="main-content">
        
        {loading ? (
          <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-3" id="loading-spinner">
            <span className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin"></span>
            <span className="text-sm text-slate-500 font-semibold">Synchronizing Tables with Database...</span>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.18 }}
            >
              {activeView === 'dashboard' && (
                <Dashboard
                  players={players}
                  matches={matches}
                  onStartSetup={handleStartSetup}
                  onResumeMatch={handleResumeMatch}
                  onNavigateToPlayers={() => setActiveView('players')}
                  onNavigateToHistory={() => setActiveView('history')}
                />
              )}

              {activeView === 'players' && (
                <PlayersPage
                  players={players}
                  onAddPlayer={handleAddPlayer}
                  onDeletePlayer={handleDeletePlayer}
                  onBack={() => setActiveView('dashboard')}
                />
              )}

              {activeView === 'setup' && (
                <MatchSetup
                  gameMode={selectedGameMode}
                  players={players}
                  onStartMatch={handleStartMatch}
                  onNavigateToPlayers={() => setActiveView('players')}
                  onCancel={() => setActiveView('dashboard')}
                />
              )}

              {activeView === 'table' && currentMatch && (
                <MatchTable
                  match={currentMatch}
                  playersList={players}
                  onUpdateMatch={handleUpdateMatch}
                  onFinishMatch={handleFinishMatch}
                  onCancel={() => setActiveView('dashboard')}
                />
              )}

              {activeView === 'history' && (
                <MatchHistoryPage
                  matches={matches}
                  playersList={players}
                  onDeleteMatch={handleDeleteMatch}
                  onBack={() => setActiveView('dashboard')}
                />
              )}
            </motion.div>
          </AnimatePresence>
        )}

      </main>

    </div>
  );
}
