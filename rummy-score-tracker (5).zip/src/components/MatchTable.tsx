import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Trash2, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  X, 
  Save, 
  ArrowLeft, 
  Info, 
  Undo,
  TrendingDown,
  Skull,
  UserPlus,
  Search
} from 'lucide-react';
import { Match, Player, GameMode } from '../types';

interface MatchTableProps {
  match: Match;
  playersList: Player[]; // Full player directory
  onUpdateMatch: (match: Match) => Promise<boolean>;
  onFinishMatch: (match: Match, winnerId: string, loserId: string) => Promise<boolean>;
  onCancel: () => void;
  onCancelMatch?: (matchId: string) => Promise<any>;
}

export default function MatchTable({
  match,
  playersList,
  onUpdateMatch,
  onFinishMatch,
  onCancel,
  onCancelMatch
}: MatchTableProps) {
  // Local state for the editable rounds.
  const [rounds, setRounds] = useState<Record<string, number>[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [gameOverAlert, setGameOverAlert] = useState<string | null>(null);

  // States for cancellation confirm modal
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);

  // States for adding a new player mid-match
  const [isAddPlayerModalOpen, setIsAddPlayerModalOpen] = useState(false);
  const [searchAddPlayer, setSearchAddPlayer] = useState('');

  // Ref to track the last saved JSON string representation of rounds
  const lastSavedRoundsJson = useRef<string>('');

  // Auto-save status
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

  // Initialize rounds state when match changes
  useEffect(() => {
    if (match && match.rounds) {
      const copiedRounds = match.rounds.map(r => ({ ...r }));
      setRounds(copiedRounds);
      lastSavedRoundsJson.current = JSON.stringify(copiedRounds);
      setAutoSaveStatus('idle');
    }
  }, [match]);

  // Function to save draft automatically
  const autoSaveDraft = async (currentRounds: Record<string, number>[]) => {
    setAutoSaveStatus('saving');
    setSaveError(null);

    const currentTotals: Record<string, number> = {};
    match.players.forEach(p => {
      currentTotals[p.id] = 0;
    });
    currentRounds.forEach((round, rIndex) => {
      match.players.forEach(p => {
        const score = Number(round[p.id]) || 0;
        // Sevens mode Round 1 is doubled
        const finalScore = (rIndex === 0 && match.gameMode === 'sevens') ? (score * 2) : score;
        currentTotals[p.id] += finalScore;
      });
    });

    const updatedPlayers = match.players.map(p => ({
      ...p,
      totalScore: currentTotals[p.id] || 0
    }));

    const cleanedRounds = currentRounds.map(r => {
      const cleanRound: Record<string, number> = {};
      match.players.forEach(p => {
        cleanRound[p.id] = Number(r[p.id]) || 0;
      });
      return cleanRound;
    });

    const updatedMatch: Match = {
      ...match,
      players: updatedPlayers,
      rounds: cleanedRounds,
    };

    try {
      const success = await onUpdateMatch(updatedMatch);
      if (success) {
        lastSavedRoundsJson.current = JSON.stringify(cleanedRounds);
        setAutoSaveStatus('saved');
      } else {
        setAutoSaveStatus('error');
        setSaveError('Failed to auto-save draft. Please check your network connection.');
      }
    } catch (e) {
      console.error('Auto-save error:', e);
      setAutoSaveStatus('error');
      setSaveError('Failed to auto-save draft. Please try again.');
    }
  };

  // Debounced auto-save effect
  useEffect(() => {
    if (!match || match.status !== 'active') return;
    if (rounds.length === 0) return; // Wait for initial rounds state to load

    const currentRoundsJson = JSON.stringify(rounds);
    // Only save if rounds actually changed compared to the last saved state
    if (currentRoundsJson === lastSavedRoundsJson.current || lastSavedRoundsJson.current === '') {
      return;
    }

    // Set status to saving immediately when the user starts changing things
    setAutoSaveStatus('saving');

    const timer = setTimeout(() => {
      autoSaveDraft(rounds);
    }, 1000); // 1 second debounce to let the user finish entering the number

    return () => clearTimeout(timer);
  }, [rounds, match]);

  // Map to easily access a player's avatarColor from the original directory list
  const getPlayerColor = (playerId: string) => {
    const player = playersList.find(p => p.id === playerId);
    return player ? player.avatarColor : 'bg-stone-600';
  };

  // Compute total scores for each player in real-time from the local rounds state
  const computeTotals = () => {
    const totals: Record<string, number> = {};
    match.players.forEach(p => {
      totals[p.id] = 0;
    });

    rounds.forEach((round, rIndex) => {
      match.players.forEach(p => {
        const score = Number(round[p.id]) || 0;
        // Sevens mode Round 1 is doubled
        const finalScore = (rIndex === 0 && match.gameMode === 'sevens') ? (score * 2) : score;
        totals[p.id] += finalScore;
      });
    });

    return totals;
  };

  const totals = computeTotals();

  // Sort players for the live leaderboard: lowest score is first (winning), highest is last (losing)
  const getLeaderboard = () => {
    return [...match.players]
      .map(p => ({
        ...p,
        totalScore: totals[p.id] || 0
      }))
      .sort((a, b) => a.totalScore - b.totalScore);
  };

  const leaderboard = getLeaderboard();
  const currentLeader = leaderboard[0];
  const currentLoser = leaderboard[leaderboard.length - 1];

  const isGameOver = match.gameMode === 'opens' && match.players.some(p => (totals[p.id] || 0) >= 320);

  // Handle adding a player to the currently playing table/match
  const handleAddPlayerToMatch = async (playerToAdd: Player) => {
    if (match.players.some(p => p.id === playerToAdd.id)) {
      return;
    }

    // 1. Identify the last completed round index where at least one existing player has a score > 0
    let lastCompletedRoundIdx = -1;
    for (let r = rounds.length - 1; r >= 0; r--) {
      const hasScore = match.players.some(p => (rounds[r]?.[p.id] || 0) > 0);
      if (hasScore) {
        lastCompletedRoundIdx = r;
        break;
      }
    }

    // 2. Calculate the highest cumulative score of any player up to the last completed round
    let highestCumulativeScore = 0;
    if (lastCompletedRoundIdx >= 0) {
      match.players.forEach(p => {
        let sum = 0;
        for (let r = 0; r <= lastCompletedRoundIdx; r++) {
          const score = Number(rounds[r]?.[p.id]) || 0;
          const finalScore = (r === 0 && match.gameMode === 'sevens') ? (score * 2) : score;
          sum += finalScore;
        }
        if (sum > highestCumulativeScore) {
          highestCumulativeScore = sum;
        }
      });
    }

    // Starting points is highest cumulative score + 2
    const penaltyPoints = lastCompletedRoundIdx >= 0 ? highestCumulativeScore + 2 : 0;

    // 3. Update rounds: set penaltyPoints in the last completed round, 0 in all other previous rounds
    const updatedRounds = rounds.map((r, rIdx) => {
      const updatedRound = { ...r };
      if (rIdx === lastCompletedRoundIdx) {
        updatedRound[playerToAdd.id] = penaltyPoints;
      } else {
        updatedRound[playerToAdd.id] = 0;
      }
      return updatedRound;
    });

    // 4. Update the match.players array
    const newMatchPlayer = {
      id: playerToAdd.id,
      name: playerToAdd.name,
      totalScore: penaltyPoints
    };

    const updatedMatchPlayers = [...match.players, newMatchPlayer];

    const updatedMatch: Match = {
      ...match,
      players: updatedMatchPlayers,
      rounds: updatedRounds,
    };

    setIsSaving(true);
    setSaveError(null);
    setAutoSaveStatus('saving');

    try {
      const success = await onUpdateMatch(updatedMatch);
      if (success) {
        setRounds(updatedRounds);
        lastSavedRoundsJson.current = JSON.stringify(updatedRounds);
        setAutoSaveStatus('saved');
        setIsAddPlayerModalOpen(false);
      } else {
        setSaveError('Failed to add player to the table. Please try again.');
        setAutoSaveStatus('error');
      }
    } catch (e) {
      console.error(e);
      setSaveError('Failed to add player to the table. Please try again.');
      setAutoSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  // Detect Opens game over condition: score >= 320
  useEffect(() => {
    if (match.gameMode === 'opens' && match.status === 'active') {
      const reached320 = match.players.find(p => (totals[p.id] || 0) >= 320);
      if (reached320) {
        setGameOverAlert(
          `🏆 GAME OVER: ${reached320.name} has crossed the 320 point ceiling (${totals[reached320.id]} points). No more rounds can be added. Please Lock & Archive this match to finalize results.`
        );
      } else {
        setGameOverAlert(null);
      }
    }
  }, [totals, match.gameMode, match.players, match.status]);

  // Handle cell input changes
  const handleScoreChange = (roundIndex: number, playerId: string, value: string) => {
    // Strip non-numeric characters to keep it as an integer
    let cleanValue = value.replace(/[^0-9]/g, '');

    // Strip leading zeroes if there are any, except if it's just "0"
    if (cleanValue.length > 1 && cleanValue.startsWith('0')) {
      cleanValue = cleanValue.replace(/^0+/, '');
      if (cleanValue === '') {
        cleanValue = '0';
      }
    }

    if (cleanValue === '') {
      setRounds(prev => {
        const updated = [...prev];
        updated[roundIndex] = {
          ...updated[roundIndex],
          [playerId]: '' as any
        };
        return updated;
      });
      return;
    }

    const parsed = parseInt(cleanValue, 10);
    const numericValue = isNaN(parsed) ? 0 : Math.max(0, parsed);

    setRounds(prev => {
      const updated = [...prev];
      updated[roundIndex] = {
        ...updated[roundIndex],
        [playerId]: numericValue
      };
      return updated;
    });
  };

  // Add a new round (Only for Opens)
  const handleAddRound = () => {
    if (match.gameMode !== 'opens' || isGameOver) return;
    const newRoundMap: Record<string, number> = {};
    match.players.forEach(p => {
      newRoundMap[p.id] = 0;
    });
    setRounds(prev => [...prev, newRoundMap]);
  };

  // Remove the last round (Only for Opens, if there are multiple rounds)
  const handleRemoveLastRound = () => {
    if (match.gameMode !== 'opens' || rounds.length <= 1) return;
    setRounds(prev => prev.slice(0, -1));
  };

  // Save changes to database (without finishing the match)
  const handleSaveDraft = async () => {
    setIsSaving(true);
    setSaveError(null);
    setAutoSaveStatus('saving');
    const updatedPlayers = match.players.map(p => ({
      ...p,
      totalScore: totals[p.id] || 0
    }));

    const cleanedRounds = rounds.map(r => {
      const cleanRound: Record<string, number> = {};
      match.players.forEach(p => {
        cleanRound[p.id] = Number(r[p.id]) || 0;
      });
      return cleanRound;
    });

    const updatedMatch: Match = {
      ...match,
      players: updatedPlayers,
      rounds: cleanedRounds,
    };

    try {
      const success = await onUpdateMatch(updatedMatch);
      if (success) {
        lastSavedRoundsJson.current = JSON.stringify(cleanedRounds);
        setAutoSaveStatus('saved');
      } else {
        setSaveError('Failed to save draft. Please check Firestore database connection.');
        setAutoSaveStatus('error');
      }
    } catch (e) {
      console.error(e);
      setSaveError('Failed to save draft. Please try again.');
      setAutoSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  // Finalize and conclude the entire match
  const handleFinalizeMatch = async () => {
    setIsSaving(true);
    setSaveError(null);
    const updatedPlayers = match.players.map(p => ({
      ...p,
      totalScore: totals[p.id] || 0
    }));

    // Re-calculate leader/loser to avoid stale closures
    const sorted = [...updatedPlayers].sort((a, b) => a.totalScore - b.totalScore);
    const winner = sorted[0];
    const loser = sorted[sorted.length - 1];

    const cleanedRounds = rounds.map(r => {
      const cleanRound: Record<string, number> = {};
      match.players.forEach(p => {
        cleanRound[p.id] = Number(r[p.id]) || 0;
      });
      return cleanRound;
    });

    const finalizedMatch: Match = {
      ...match,
      players: updatedPlayers,
      rounds: cleanedRounds,
      status: 'completed',
      winnerId: winner.id,
      loserId: loser.id,
    };

    try {
      const success = await onFinishMatch(finalizedMatch, winner.id, loser.id);
      if (!success) {
        setSaveError('Failed to finalize and save match. Please check Firestore database connection.');
      }
    } catch (e) {
      console.error(e);
      setSaveError('Failed to finalize match. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancelMatchSubmit = async () => {
    if (!onCancelMatch) return;
    setIsCancelling(true);
    try {
      await onCancelMatch(match.id);
      setIsCancelConfirmOpen(false);
    } catch (e) {
      console.error("Error cancelling match", e);
      setSaveError("Failed to cancel the game. Please check your database connection.");
      setIsCancelConfirmOpen(false);
    } finally {
      setIsCancelling(false);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto" id="match-table-root">
      
      {/* Header and Control Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-stone-850 pb-5">
        <div>
          <button
            onClick={onCancel}
            className="inline-flex items-center gap-1.5 text-stone-500 hover:text-stone-300 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer mb-2"
          >
            <ArrowLeft size={14} />
            <span>Back to Dashboard</span>
          </button>
          
          <div className="flex items-center gap-2">
            <h1 className="text-xl md:text-2xl font-serif text-[#c5a059] tracking-wider uppercase" id="table-header-title">
              Scoring Sheet <span className="text-stone-500 font-mono">#{match.id.slice(0, 8).toUpperCase()}</span>
            </h1>
            <span className={`px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest rounded border ${
              match.status === 'active' ? 'bg-gold/10 text-gold border-gold/25' : 'bg-stone-900 text-stone-500 border-stone-800'
            }`}>
              {match.status}
            </span>
          </div>
          <p className="text-[10px] text-stone-500 font-mono mt-1">
            Table configured {new Date(match.date).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}
          </p>
        </div>

        {/* Top Controls */}
        {match.status === 'active' && (
          <div className="flex items-center flex-wrap gap-3">
            {/* Auto-save Status Indicator */}
            <div className="text-[10px] font-medium font-mono flex items-center gap-1.5 bg-stone-900/40 px-2 py-1 rounded border border-stone-850">
              {autoSaveStatus === 'idle' && (
                <span className="text-stone-500 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-stone-600"></span>
                  <span>Draft Idle</span>
                </span>
              )}
              {autoSaveStatus === 'saving' && (
                <span className="text-amber-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                  <span>Saving...</span>
                </span>
              )}
              {autoSaveStatus === 'saved' && (
                <span className="text-emerald-400 flex items-center gap-1">
                  <span className="text-emerald-400 font-sans font-bold">✓</span>
                  <span>Auto-saved</span>
                </span>
              )}
              {autoSaveStatus === 'error' && (
                <span className="text-red-400 flex items-center gap-1">
                  <span>⚠️</span>
                  <span>Save failed</span>
                </span>
              )}
            </div>

            {match.players.length < 9 && (
              <button
                onClick={() => {
                  setIsAddPlayerModalOpen(true);
                  setSearchAddPlayer('');
                }}
                disabled={isSaving}
                className="px-3.5 py-2 border border-stone-800 hover:bg-[#c5a059]/10 hover:border-[#c5a059]/30 text-gold rounded text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5"
                title="Add player to table"
              >
                <UserPlus size={13} />
                <span>Add Player</span>
              </button>
            )}

            <button
              onClick={handleSaveDraft}
              disabled={isSaving || autoSaveStatus === 'saving'}
              className="px-3.5 py-2 border border-stone-800 hover:bg-stone-900 text-stone-300 hover:text-white rounded text-xs font-bold uppercase tracking-wider transition-all cursor-pointer"
              title="Save draft"
            >
              <Save size={13} className="inline mr-1" />
              <span>Save Draft</span>
            </button>

            {onCancelMatch && (
              <button
                onClick={() => setIsCancelConfirmOpen(true)}
                disabled={isSaving}
                className="px-3.5 py-2 border border-red-900/30 hover:border-red-500/30 hover:bg-red-950/10 text-red-400 hover:text-red-300 rounded text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5"
                title="Cancel game and clear this running table"
              >
                <Trash2 size={13} />
                <span>Cancel Game</span>
              </button>
            )}

            <button
              onClick={handleFinalizeMatch}
              disabled={isSaving}
              className="px-4 py-2 bg-gold hover:bg-gold-hover text-black rounded text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <CheckCircle2 size={13} />
              <span>Lock & Archive Game</span>
            </button>
          </div>
        )}
      </div>

      {saveError && (
        <div className="p-3 bg-red-950/20 border border-red-900/30 rounded text-red-400 text-xs flex items-center gap-2 animate-pulse" id="save-match-error">
          <AlertTriangle size={14} className="text-red-500 shrink-0" />
          <span>{saveError}</span>
        </div>
      )}

      {/* Warning Banners based on game rules */}
      <div className="space-y-3">
        {match.gameMode === 'sevens' && (
          <div className="p-4 bg-[#13110f] border border-gold/20 rounded text-gold/90 flex items-start gap-3 shadow-md">
            <Info className="text-gold shrink-0 mt-0.5" size={16} />
            <div className="text-xs leading-relaxed">
              <span className="font-serif font-bold text-sm uppercase tracking-wider text-gold block">Sevens Rummy protocol</span>
              <p className="mt-1 text-stone-400">
                Exactly <strong>7 games</strong> will be recorded. Game 7 is the final round. 
                <span className="text-gold font-medium"> The player who gets the highest cumulative points is the overall loser!</span> Keep scores low.
              </p>
            </div>
          </div>
        )}

        {match.gameMode === 'opens' && (
          <div className="p-4 bg-[#111314] border border-stone-800 rounded text-stone-300 flex items-start gap-3 shadow-md">
            <Info className="text-[#c5a059] shrink-0 mt-0.5" size={16} />
            <div className="text-xs leading-relaxed">
              <span className="font-serif font-bold text-sm uppercase tracking-wider text-[#c5a059] block">Open Joker Rummy protocol</span>
              <p className="mt-1 text-stone-400">
                Enter score sheet points round-by-round. When any participant hits or exceeds <strong>320 points</strong>, it is instant game over. The lowest score at that point wins.
              </p>
            </div>
          </div>
        )}

        {/* Live game-over alert for Opens */}
        <AnimatePresence>
          {gameOverAlert && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="p-4 bg-red-950/15 border border-red-900/30 rounded text-red-400 flex items-start gap-3 shadow-lg"
            >
              <AlertTriangle className="text-red-500 shrink-0 mt-0.5 animate-pulse" size={18} />
              <div className="text-xs">
                <span className="font-bold block text-sm text-red-300 uppercase tracking-wider">Ceiling Reached (320 Points limit)!</span>
                <p className="mt-1 text-stone-400 leading-relaxed">{gameOverAlert}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Grid: 1. Live Standings Leaderboard & 2. Scoring Spreadsheet */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Live Standings Leaderboard (1 Col on Desktop) */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-dark-card border border-stone-800 rounded-xl p-4 shadow-lg">
            <h3 className="font-serif text-gold text-[10px] uppercase tracking-[0.2em] mb-4 flex items-center justify-between border-b border-stone-900 pb-2">
              <span>Live Rank</span>
              <span className="text-[8px] text-stone-500 lowercase font-mono">lowest pts wins</span>
            </h3>

            <div className="space-y-2">
              {leaderboard.map((p, index) => {
                const isWinner = index === 0;
                const isLoser = index === leaderboard.length - 1;
                const scoreLimitDanger = match.gameMode === 'opens' && p.totalScore >= 300;

                return (
                  <div 
                    key={p.id}
                    className={`flex items-center justify-between p-2.5 rounded border transition-all ${
                      isWinner 
                        ? 'bg-gold/5 border-gold/15 text-gold' 
                        : isLoser 
                        ? 'bg-red-950/15 border-red-900/20 text-red-400'
                        : 'bg-stone-900/30 border-stone-850 text-stone-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[10px] font-bold text-stone-500 w-4">
                        {index === 0 ? '👑' : `#${index + 1}`}
                      </span>
                      <div className={`w-6 h-6 rounded ${getPlayerColor(p.id)} text-white flex items-center justify-center font-bold text-[10px] uppercase shrink-0`}>
                        {p.name.charAt(0)}
                      </div>
                      <span className="text-xs font-semibold truncate" title={p.name}>
                        {p.name}
                      </span>
                    </div>

                    <div className="text-right shrink-0">
                      <span className={`text-xs font-mono font-bold ${
                        scoreLimitDanger ? 'text-red-400 animate-pulse' : ''
                      }`}>
                        {p.totalScore}
                      </span>
                      {isWinner && (
                        <span className="text-[8px] uppercase tracking-wider text-gold block leading-tight mt-0.5">
                          Champion
                        </span>
                      )}
                      {isLoser && (
                        <span className="text-[8px] uppercase tracking-wider text-red-500 block leading-tight mt-0.5">
                          Danger
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick game status insights */}
          <div className="bg-[#0c0a09] border border-stone-800 rounded-xl p-4 text-xs space-y-2.5 text-stone-400 shadow-md">
            <h4 className="font-serif font-semibold text-gold uppercase tracking-wider text-[10px]">Table Stats</h4>
            <div className="flex justify-between py-1 border-b border-stone-900">
              <span className="text-stone-500">Current Leader:</span>
              <strong className="text-gold font-bold">{currentLeader?.name} ({totals[currentLeader?.id] || 0} pts)</strong>
            </div>
            <div className="flex justify-between py-1 border-b border-stone-900">
              <span className="text-stone-500">Highest Point:</span>
              <strong className="text-red-400 font-bold">{currentLoser?.name} ({totals[currentLoser?.id] || 0} pts)</strong>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-stone-500">Game Format:</span>
              <span className="font-semibold text-stone-300">
                {match.gameMode === 'sevens' ? 'Sevens' : 'Open Joker'}
              </span>
            </div>
          </div>
        </div>

        {/* Main Scoring Sheet / Spreadsheet (3 Cols on Desktop) */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-dark-card border border-stone-800 rounded-xl shadow-lg overflow-hidden">
            
            {/* Table Spreadsheet Wrapper */}
            <div className="overflow-x-auto overflow-y-auto max-h-[60vh] relative">
              <table className="w-full text-left border-collapse" id="scoring-table">
                <thead>
                  <tr className="bg-[#121212]">
                    <th className="py-3.5 px-4 text-[10px] uppercase tracking-wider font-semibold text-stone-500 w-24 sticky top-0 z-10 bg-[#121212] border-b border-stone-800">
                      Rounds List
                    </th>
                    {match.players.map((p) => (
                      <th key={p.id} className="py-3 px-3 text-xs font-semibold text-stone-200 text-center min-w-[100px] border-l border-stone-850 sticky top-0 z-10 bg-[#121212] border-b border-stone-800">
                        <div className="flex flex-col items-center gap-1">
                          <div className={`w-7 h-7 rounded ${getPlayerColor(p.id)} text-white flex items-center justify-center font-bold text-xs uppercase shadow-inner`}>
                            {p.name.charAt(0)}
                          </div>
                          <span className="font-semibold text-xs text-stone-300 truncate max-w-[90px]" title={p.name}>
                            {p.name}
                          </span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody className="divide-y divide-stone-900">
                  {rounds.map((round, rIndex) => {
                    const isLastRoundSevens = match.gameMode === 'sevens' && rIndex === 6;

                    return (
                      <tr 
                        key={rIndex} 
                        className={`hover:bg-stone-900/20 transition-colors ${
                          isLastRoundSevens ? 'bg-amber-950/10 hover:bg-amber-950/20' : ''
                        }`}
                      >
                        <td className="py-3 px-4 font-semibold text-stone-400 text-xs">
                          {isLastRoundSevens ? (
                            <span className="flex items-center gap-1 font-bold text-gold">
                              <Skull size={11} />
                              Game 7 (Final)
                            </span>
                          ) : rIndex === 0 && match.gameMode === 'sevens' ? (
                            <span className="flex flex-col">
                              <span>Round 1</span>
                              <span className="text-[9px] text-[#c5a059] font-semibold tracking-tighter uppercase leading-tight mt-0.5">x2 Multiplier</span>
                            </span>
                          ) : (
                            <span>Round {rIndex + 1}</span>
                          )}
                        </td>

                        {match.players.map((p) => (
                          <td key={p.id} className="py-2.5 px-2 text-center border-l border-stone-850">
                            <div className="flex flex-col items-center gap-1">
                              <input
                                type="text"
                                inputMode="numeric"
                                pattern="[0-9]*"
                                value={round[p.id] === undefined ? '' : String(round[p.id])}
                                onChange={(e) => handleScoreChange(rIndex, p.id, e.target.value)}
                                onFocus={(e) => {
                                  e.target.select();
                                }}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    e.preventDefault();
                                    const inputs = Array.from(document.querySelectorAll('#scoring-table input:not([disabled])')) as HTMLInputElement[];
                                    const index = inputs.indexOf(e.currentTarget);
                                    if (index !== -1 && index + 1 < inputs.length) {
                                      inputs[index + 1].focus();
                                      inputs[index + 1].select();
                                    }
                                  }
                                }}
                                onBlur={(e) => {
                                  if (e.target.value === '') {
                                    handleScoreChange(rIndex, p.id, '0');
                                  }
                                }}
                                disabled={match.status !== 'active'}
                                className={`w-20 px-2 py-1.5 border rounded text-center font-mono font-bold text-xs focus:outline-none focus:border-gold transition-colors ${
                                  match.status !== 'active' 
                                    ? 'bg-stone-900/60 text-stone-600 border-stone-850 cursor-not-allowed' 
                                    : isLastRoundSevens
                                    ? 'bg-amber-950/20 border-gold/30 text-gold focus:border-gold shadow-sm'
                                    : rIndex === 0 && match.gameMode === 'sevens'
                                    ? 'bg-amber-950/5 border-amber-900/40 text-amber-500 focus:border-gold'
                                    : 'bg-[#121212] border-stone-800 text-stone-200 focus:border-gold'
                                }`}
                                placeholder="0"
                              />
                              {rIndex === 0 && match.gameMode === 'sevens' && Number(round[p.id]) > 0 && (
                                <span className="text-[9px] text-amber-500 font-mono font-bold leading-none animate-fade-in mt-0.5">
                                  = {Number(round[p.id]) * 2} pts
                                </span>
                              )}
                            </div>
                          </td>
                        ))}
                      </tr>
                    );
                  })}

                  {/* Running totals summation row */}
                  <tr className="bg-stone-900/50 font-bold border-t border-stone-800">
                    <td className="py-3.5 px-4 text-[10px] font-bold text-gold uppercase tracking-wider">
                      Cumulative
                    </td>
                    {match.players.map((p) => {
                      const limitDanger = match.gameMode === 'opens' && totals[p.id] >= 320;
                      return (
                        <td key={p.id} className="py-3 px-3 text-center text-xs font-mono font-bold border-l border-stone-800">
                          <span className={`px-2.5 py-1 rounded text-xs font-bold font-mono ${
                            limitDanger 
                              ? 'bg-red-900 text-red-100 border border-red-600 animate-pulse' 
                              : 'bg-gold/5 text-gold border border-gold/10'
                          }`}>
                            {totals[p.id] || 0}
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Bottom Actions for custom Round adding in Opens Mode */}
            {match.gameMode === 'opens' && match.status === 'active' && (
              <div className="p-4 bg-[#121212] border-t border-stone-800 flex items-center justify-between gap-2">
                <button
                  onClick={handleRemoveLastRound}
                  disabled={rounds.length <= 1}
                  className="px-3 py-1.5 border border-stone-800 hover:bg-red-950 hover:border-red-900 hover:text-red-400 disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:border-stone-800 disabled:hover:text-stone-500 rounded text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  title="Remove bottom-most round scorecard"
                >
                  <Undo size={12} className="inline mr-1" />
                  <span>Remove Round</span>
                </button>

                <button
                  onClick={handleAddRound}
                  disabled={isGameOver}
                  className="px-3 py-1.5 bg-stone-900 border border-stone-800 text-gold hover:text-white rounded text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Plus size={13} />
                  <span>Add Score Row</span>
                </button>
              </div>
            )}
          </div>

          {/* Quick confirmation guidelines block */}
          <div className="bg-[#0c0a09] border border-stone-800 rounded-xl p-5 text-xs text-stone-500 space-y-2">
            <h4 className="font-serif font-bold text-stone-400 uppercase tracking-wider text-[10px]">Card-room Scorer Protocols</h4>
            <ul className="list-disc pl-4 space-y-1 text-stone-500 leading-relaxed">
              <li>Enter player scores in matching rounds. Draft is saved continuously by clicking <strong>Save Draft</strong>.</li>
              <li>Input positive numbers only. Enter 0 if a participant won the round.</li>
              <li>Once scores are locked and checked, click <strong>Lock & Archive Game</strong>. This registers outcomes securely to database profiles and updates directory ranks.</li>
            </ul>
          </div>
        </div>

      </div>

      {/* Add Player Modal */}
      <AnimatePresence>
        {isAddPlayerModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm" id="add-player-modal-overlay">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="bg-stone-900 border border-stone-800 rounded-lg p-6 max-w-md w-full shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]"
              id="add-player-modal"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-gold via-[#c5a059] to-gold"></div>
              
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-serif font-semibold text-stone-200 flex items-center gap-2">
                    <UserPlus size={18} className="text-gold" />
                    <span>Add Member to Table</span>
                  </h3>
                  <p className="text-xs text-stone-500">Currently playing table: max 9 players</p>
                </div>
                <button
                  onClick={() => setIsAddPlayerModalOpen(false)}
                  className="p-1 rounded bg-stone-950 border border-stone-800 hover:bg-stone-800 text-stone-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>

              {/* Search filter */}
              <div className="relative mb-4">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-500">
                  <Search size={14} />
                </span>
                <input
                  type="text"
                  placeholder="Search registered players..."
                  value={searchAddPlayer}
                  onChange={(e) => setSearchAddPlayer(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-950 border border-stone-800 rounded text-stone-200 text-xs focus:outline-none focus:border-gold transition-colors placeholder:text-stone-700"
                  autoFocus
                />
              </div>

              {/* Player list container */}
              <div className="flex-1 overflow-y-auto max-h-[280px] pr-1 space-y-2 custom-scrollbar">
                {(() => {
                  const availablePlayers = playersList.filter(
                    p => !match.players.some(mp => mp.id === p.id)
                  );
                  const filtered = availablePlayers.filter(
                    p => p.name.toLowerCase().includes(searchAddPlayer.toLowerCase())
                  );

                  if (filtered.length === 0) {
                    return (
                      <div className="text-center py-8 text-stone-600 text-xs">
                        {availablePlayers.length === 0 
                          ? 'All registered players are currently playing at this table.' 
                          : 'No matching players found.'}
                      </div>
                    );
                  }

                  return filtered.map((player) => (
                    <div
                      key={player.id}
                      onClick={() => handleAddPlayerToMatch(player)}
                      className="flex items-center justify-between p-2.5 bg-stone-950/40 border border-stone-850 hover:bg-stone-950/90 hover:border-gold/30 rounded-lg cursor-pointer transition-all group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded ${player.avatarColor || 'bg-stone-600'} text-white flex items-center justify-center font-bold text-xs uppercase shadow-inner`}>
                          {player.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-stone-300 group-hover:text-gold transition-colors">{player.name}</p>
                          <p className="text-[10px] text-stone-500 font-mono">Wins: {player.gamesWon || 0} / Played: {player.gamesPlayed || 0}</p>
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAddPlayerToMatch(player);
                        }}
                        className="px-2.5 py-1 bg-[#c5a059]/10 border border-gold/10 hover:bg-gold hover:text-black hover:border-gold text-gold rounded text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer"
                      >
                        Join Table
                      </button>
                    </div>
                  ));
                })()}
              </div>

              {/* Point entry notice rule */}
              <div className="mt-4 p-3 bg-amber-950/10 border border-amber-900/30 rounded-lg text-[10px] text-stone-400 space-y-1">
                <p className="font-bold text-amber-500 uppercase tracking-wider flex items-center gap-1">
                  <Info size={11} />
                  <span>Late-Join Scoring Rule:</span>
                </p>
                <p className="leading-relaxed text-stone-400">
                  New players start with a score penalty of the highest score at the table + 2 on the last round.
                </p>
              </div>

              <div className="flex gap-3 mt-5 pt-3 border-t border-stone-850">
                <button
                  type="button"
                  onClick={() => setIsAddPlayerModalOpen(false)}
                  className="w-full px-4 py-2 rounded text-xs font-bold uppercase tracking-wider bg-stone-850 text-stone-400 border border-stone-800 hover:bg-stone-800 hover:text-stone-200 transition-all cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cancel Match Confirmation Modal */}
      <AnimatePresence>
        {isCancelConfirmOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm" id="cancel-match-modal-overlay">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.18 }}
              className="bg-stone-900 border border-red-950/40 rounded-lg p-6 max-w-md w-full shadow-2xl relative overflow-hidden flex flex-col"
              id="cancel-match-modal"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-red-600"></div>
              
              <div className="flex items-start gap-3.5 mb-4">
                <div className="p-2 bg-red-950/40 border border-red-900/40 text-red-500 rounded-full shrink-0">
                  <AlertTriangle size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-serif font-semibold text-stone-200">
                    Cancel Current Game?
                  </h3>
                  <p className="text-xs text-stone-500 mt-0.5">This action cannot be undone.</p>
                </div>
              </div>

              <div className="text-xs text-stone-400 leading-relaxed space-y-2 mb-6">
                <p>
                  Are you sure you want to cancel and delete the current table (<span className="font-mono text-gold">#{match.id.slice(0, 8).toUpperCase()}</span>)?
                </p>
                <p>
                  This will permanently discard all score entries for this draft match from the database and statistics.
                </p>
              </div>

              <div className="flex gap-3 justify-end pt-3 border-t border-stone-850">
                <button
                  type="button"
                  onClick={() => setIsCancelConfirmOpen(false)}
                  disabled={isCancelling}
                  className="px-4 py-2 rounded text-xs font-bold uppercase tracking-wider bg-stone-850 text-stone-400 border border-stone-800 hover:bg-stone-800 hover:text-stone-200 transition-all cursor-pointer"
                >
                  No, Continue
                </button>
                <button
                  type="button"
                  onClick={handleCancelMatchSubmit}
                  disabled={isCancelling}
                  className="px-4 py-2 rounded text-xs font-bold uppercase tracking-wider bg-red-900 text-white border border-red-800 hover:bg-red-800 transition-all cursor-pointer flex items-center gap-1.5"
                >
                  {isCancelling ? 'Cancelling...' : 'Yes, Cancel Game'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
