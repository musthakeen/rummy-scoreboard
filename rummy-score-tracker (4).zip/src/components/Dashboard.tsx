import React from 'react';
import { motion } from 'motion/react';
import { 
  Trophy, 
  Users, 
  PlayCircle, 
  Dice5, 
  TrendingUp, 
  Calendar, 
  Layers, 
  Sparkles,
  ArrowRight,
  Skull,
  Club
} from 'lucide-react';
import { Player, Match, GameMode } from '../types';

interface DashboardProps {
  players: Player[];
  matches: Match[];
  onStartSetup: (mode: GameMode) => void;
  onResumeMatch: (match: Match) => void;
  onNavigateToPlayers: () => void;
  onNavigateToHistory: () => void;
}

export default function Dashboard({
  players,
  matches,
  onStartSetup,
  onResumeMatch,
  onNavigateToPlayers,
  onNavigateToHistory
}: DashboardProps) {
  // Compute Stats
  const activeMatches = matches.filter(m => m.status === 'active');
  const completedMatches = matches.filter(m => m.status === 'completed');
  const totalPlayers = players.length;

  const totalSevens = matches.filter(m => m.gameMode === 'sevens').length;
  const totalOpens = matches.filter(m => m.gameMode === 'opens').length;

  // Find Leaderboard of players based on Win Rate (minimum 1 game played)
  const sortedLeaderboard = [...players]
    .filter(p => p.gamesPlayed > 0)
    .map(p => ({
      ...p,
      winRate: Math.round((p.gamesWon / p.gamesPlayed) * 100)
    }))
    .sort((a, b) => b.winRate - a.winRate || b.gamesWon - a.gamesWon)
    .slice(0, 5);

  const getPlayerName = (id: string) => {
    return players.find(p => p.id === id)?.name || 'Unknown';
  };

  const getPlayerColor = (id: string) => {
    return players.find(p => p.id === id)?.avatarColor || 'bg-stone-500';
  };

  return (
    <div className="space-y-8" id="dashboard-container">
      
      {/* Hero Welcome Section */}
      <div className="bg-gradient-to-br from-stone-900 via-[#141414] to-black rounded-2xl p-6 md:p-8 text-white relative overflow-hidden border border-stone-800 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        {/* Subtle Gold light effect background */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-gold/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="space-y-3 z-10">
          <div className="flex items-center gap-2">
            <span className="bg-gold/10 text-gold border border-gold/25 px-3 py-1 rounded text-[9px] font-bold uppercase tracking-[0.2em]">
              Scoring Suite ♣️ ♦️ ♠️ ♥️
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-serif text-[#c5a059] tracking-wider uppercase">Rummy Club Score Card</h1>
          <p className="text-stone-400 text-xs md:text-sm max-w-lg leading-relaxed">
            Record, calculate, and store rummy game sheets seamlessly. Features warnings on Sevens match point ceilings and automated game-over thresholds for Open Joker mode.
          </p>
        </div>

        {/* Quick Launch Buttons */}
        <div className="flex flex-wrap gap-3 z-10 shrink-0">
          <button
            onClick={() => onStartSetup('sevens')}
            className="px-4 py-2.5 bg-gold hover:bg-gold-hover text-black rounded text-xs font-bold tracking-wider uppercase transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Sparkles size={13} />
            <span>Sevens (7s)</span>
          </button>
          
          <button
            onClick={() => onStartSetup('opens')}
            className="px-4 py-2.5 bg-stone-900 hover:bg-stone-850 text-[#c5a059] border border-[#c5a059]/30 hover:border-[#c5a059] rounded text-xs font-bold tracking-wider uppercase transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <PlayCircle size={13} />
            <span>Open Joker (320)</span>
          </button>
        </div>
      </div>

      {/* Stats Cards Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="stats-grid">
        <div className="bg-dark-card border border-stone-800 p-4 rounded-xl flex items-center gap-4 shadow-md">
          <div className="p-3 bg-stone-905 text-gold border border-stone-800 rounded">
            <Users size={18} />
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold tracking-widest text-stone-500 block">Total Members</span>
            <strong className="text-lg font-bold text-stone-200">{totalPlayers}</strong>
          </div>
        </div>

        <div className="bg-dark-card border border-stone-800 p-4 rounded-xl flex items-center gap-4 shadow-md">
          <div className="p-3 bg-stone-905 text-gold border border-stone-800 rounded">
            <PlayCircle size={18} />
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold tracking-widest text-stone-500 block">Live Tables</span>
            <strong className="text-lg font-bold text-stone-200">{activeMatches.length}</strong>
          </div>
        </div>

        <div className="bg-dark-card border border-stone-800 p-4 rounded-xl flex items-center gap-4 shadow-md">
          <div className="p-3 bg-stone-905 text-gold border border-stone-800 rounded">
            <Layers size={18} />
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold tracking-widest text-stone-500 block">Saved Matches</span>
            <strong className="text-lg font-bold text-stone-200">{completedMatches.length}</strong>
          </div>
        </div>

        <div className="bg-dark-card border border-stone-800 p-4 rounded-xl flex items-center gap-4 shadow-md">
          <div className="p-3 bg-stone-905 text-gold border border-stone-800 rounded">
            <Dice5 size={18} />
          </div>
          <div>
            <span className="text-[10px] uppercase font-semibold tracking-widest text-stone-500 block">Sevens : Open Joker</span>
            <strong className="text-lg font-bold text-stone-200">{totalSevens} : {totalOpens}</strong>
          </div>
        </div>
      </div>

      {/* Main Grid: Live Matches, Leaderboard, History */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column (Span 2): Live Matches & Match History */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Active / Ongoing Tables */}
          <div className="space-y-4">
            <h2 className="text-sm uppercase tracking-[0.2em] text-gold font-bold flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />
              <span>Active Scoring Tables</span>
            </h2>

            {activeMatches.length === 0 ? (
              <div className="bg-dark-card/40 border border-stone-800 rounded-xl p-8 text-center text-xs text-stone-500">
                <p className="mb-2">No game matches are active right now.</p>
                <button 
                  onClick={() => onStartSetup('sevens')}
                  className="text-xs text-gold hover:underline font-bold"
                >
                  Configure and start a table +
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeMatches.map(match => (
                  <div 
                    key={match.id} 
                    className="bg-dark-card border border-stone-800 hover:border-gold/30 p-5 rounded-xl shadow-md transition-all relative overflow-hidden flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <span className="px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded bg-gold/10 text-gold border border-gold/20">
                          {match.gameMode === 'sevens' ? 'Sevens (7s)' : 'Open Joker (320)'}
                        </span>
                        
                        <span className="text-[10px] text-stone-500 font-mono">
                          {new Date(match.date).toLocaleDateString()}
                        </span>
                      </div>

                      <h3 className="font-serif font-semibold text-stone-200 text-sm tracking-wide">
                        Table ID: {match.id.slice(0, 8).toUpperCase()}
                      </h3>

                      {/* Members on table */}
                      <div className="flex flex-wrap gap-1.5 mt-3">
                        {match.players.map(p => (
                          <div 
                            key={p.id}
                            className="inline-flex items-center gap-1.5 bg-stone-900 border border-stone-800/80 px-2 py-0.5 rounded text-[10px] text-stone-400 font-medium"
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${getPlayerColor(p.id)}`} />
                            <span>{p.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="mt-5 pt-3 border-t border-stone-800/50">
                      <button
                        onClick={() => onResumeMatch(match)}
                        className="w-full py-2 bg-[#1c1917] hover:bg-[#292524] text-[#c5a059] border border-stone-800 rounded text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>Open Scoring Grid</span>
                        <ArrowRight size={11} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick History List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm uppercase tracking-[0.2em] text-gold font-bold flex items-center gap-2">
                <Calendar size={14} />
                <span>Recently Concluded</span>
              </h2>
              <button 
                onClick={onNavigateToHistory}
                className="text-xs font-bold uppercase tracking-wider text-stone-400 hover:text-gold cursor-pointer transition-colors"
              >
                View Archival Log
              </button>
            </div>

            {completedMatches.length === 0 ? (
              <div className="bg-dark-card/40 border border-stone-800 rounded-xl p-8 text-center text-xs text-stone-500">
                <p>No completed games recorded in local archive yet.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {completedMatches.slice(0, 3).map(match => {
                  const winner = match.players.find(p => p.id === match.winnerId);
                  const loser = match.players.find(p => p.id === match.loserId);

                  return (
                    <div 
                      key={match.id}
                      className="bg-dark-card border border-stone-800 p-4 rounded-xl shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded bg-[#1c1917] text-gold border border-stone-800">
                            {match.gameMode === 'sevens' ? 'Sevens' : 'Open Joker'}
                          </span>
                          <span className="text-xs font-serif font-semibold text-stone-200">
                            Table {match.id.slice(0, 6).toUpperCase()}
                          </span>
                        </div>

                        <p className="text-[10px] text-stone-500 mt-1">
                          Ended {new Date(match.date).toLocaleDateString()} at {new Date(match.date).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>

                      {/* Winner vs Loser Stats */}
                      <div className="flex items-center gap-4 text-xs">
                        {winner && (
                          <div className="flex items-center gap-1.5 bg-gold/5 text-gold border border-gold/15 px-2.5 py-1 rounded">
                            <Trophy size={11} />
                            <span>Champion: <strong>{winner.name}</strong> ({winner.totalScore} pts)</span>
                          </div>
                        )}

                        {loser && (
                          <div className="flex items-center gap-1.5 bg-red-950/10 text-red-400 border border-red-900/30 px-2.5 py-1 rounded">
                            <Skull size={11} />
                            <span>Loser: <strong>{loser.name}</strong> ({loser.totalScore} pts)</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* Right Column: Leaderboard Directory */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm uppercase tracking-[0.2em] text-gold font-bold flex items-center gap-2">
              <Trophy size={14} className="text-gold" />
              <span>Standings</span>
            </h2>
            <button 
              onClick={onNavigateToPlayers}
              className="text-xs font-bold uppercase tracking-wider text-stone-400 hover:text-gold cursor-pointer transition-colors"
            >
              All Members
            </button>
          </div>

          <div className="bg-dark-card border border-stone-800 rounded-xl p-5 shadow-lg">
            {sortedLeaderboard.length === 0 ? (
              <div className="py-12 text-center text-xs text-stone-500 space-y-1">
                <p>No score statistics generated yet.</p>
                <p>Play matches to populate the leader standings.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {sortedLeaderboard.map((p, index) => (
                  <div key={p.id} className="flex items-center justify-between border-b border-stone-900 pb-3 last:border-0 last:pb-0">
                    <div className="flex items-center gap-3">
                      <span className={`w-5 font-serif font-bold text-xs ${
                        index === 0 ? 'text-gold' : index === 1 ? 'text-stone-300' : index === 2 ? 'text-amber-800' : 'text-stone-600'
                      }`}>
                        #{index + 1}
                      </span>
                      
                      <div className={`w-8 h-8 rounded ${p.avatarColor} text-white flex items-center justify-center font-bold text-xs uppercase shrink-0`}>
                        {p.name.charAt(0)}
                      </div>

                      <div>
                        <strong className="text-xs font-semibold text-stone-200 block leading-tight">{p.name}</strong>
                        <span className="text-[9px] text-stone-500 uppercase tracking-wider">
                          {p.gamesWon}W / {p.gamesPlayed}G
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-bold text-gold block">{p.winRate}%</span>
                      <span className="text-[8px] uppercase tracking-wider text-stone-500">Win rate</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}

