import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Users, Search, Check, AlertCircle, PlusCircle, ArrowLeft } from 'lucide-react';
import { Player, GameMode } from '../types';

interface MatchSetupProps {
  gameMode: GameMode;
  players: Player[];
  onStartMatch: (players: Player[]) => Promise<boolean>;
  onNavigateToPlayers: () => void;
  onCancel: () => void;
}

export default function MatchSetup({
  gameMode,
  players,
  onStartMatch,
  onNavigateToPlayers,
  onCancel
}: MatchSetupProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isStarting, setIsStarting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Filter players based on search query
  const filteredPlayers = players.filter((player) =>
    player.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const togglePlayer = (id: string) => {
    setErrorMsg(null);
    setSelectedIds((prev) => {
      if (prev.includes(id)) {
        return prev.filter((pId) => pId !== id);
      } else {
        if (prev.length >= 9) {
          setErrorMsg('Maximum 9 players can join a match.');
          return prev;
        }
        return [...prev, id];
      }
    });
  };

  const handleStart = async () => {
    if (selectedIds.length < 2) {
      setErrorMsg('Minimum 2 players are required to start a match.');
      return;
    }
    if (selectedIds.length > 9) {
      setErrorMsg('Maximum 9 players are allowed.');
      return;
    }

    setIsStarting(true);
    setErrorMsg(null);

    // Get the actual player objects
    const selectedPlayers = players.filter((p) => selectedIds.includes(p.id));
    
    try {
      const success = await onStartMatch(selectedPlayers);
      if (!success) {
        setErrorMsg('Failed to create match. Please check Firestore database connection.');
        setIsStarting(false);
      }
    } catch (e) {
      console.error(e);
      setErrorMsg('Failed to create match. Please try again.');
      setIsStarting(false);
    }
  };

  const selectedPlayersCount = selectedIds.length;

  return (
    <div className="space-y-6 max-w-4xl mx-auto" id="match-setup-container">
      {/* Back to dashboard button */}
      <div>
        <button
          onClick={onCancel}
          className="flex items-center gap-1.5 text-stone-500 hover:text-stone-300 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>Back to Dashboard</span>
        </button>
      </div>

      <div className="bg-dark-card border border-stone-800 rounded-xl p-6 md:p-8 shadow-xl">
        {/* Title */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-stone-900">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-[0.2em] rounded bg-gold/10 text-gold border border-gold/25">
                {gameMode === 'sevens' ? 'Sevens (7s) Mode' : 'Open Joker (320) Mode'}
              </span>
            </div>
            <h1 className="text-2xl font-serif text-[#c5a059] tracking-wider uppercase mt-2.5" id="setup-title">
              Open Score Sheet Table
            </h1>
            <p className="text-xs text-stone-500 mt-1">
              Select players who are playing at the table. Supports 2 to 9 players.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-[#121212] px-4 py-2 rounded border border-stone-800">
            <Users className="text-stone-500" size={15} />
            <span className="text-xs text-stone-400">
              Selected: <strong className="text-gold font-bold">{selectedPlayersCount}/9</strong>
            </span>
          </div>
        </div>

        {/* Dynamic game mode instruction alert (Styled as an authentic mahogany table card) */}
        <div className="p-4 rounded border mt-6 bg-[#13110f] border-gold/20 text-gold/90 flex items-start gap-3">
          <AlertCircle className="shrink-0 mt-0.5 text-gold" size={16} />
          <div className="text-xs space-y-1">
            <p className="font-serif font-semibold text-sm uppercase tracking-wider text-gold">
              {gameMode === 'sevens' ? 'Sevens (7s) Protocol' : 'Open Joker (320) Protocol'}
            </p>
            {gameMode === 'sevens' ? (
              <p className="text-stone-400 leading-relaxed">
                Exactly <strong>7 games</strong> will be played in total. The 7th game is the final round! 
                <span className="text-gold font-medium"> The player with the highest overall points is the loser.</span> Keep score cards low.
              </p>
            ) : (
              <p className="text-stone-400 leading-relaxed">
                Scorecards continue until any player reaches or exceeds <strong className="text-gold">320 points</strong>. 
                Once someone gets 320, the game finishes immediately and the player with the lowest score wins!
              </p>
            )}
          </div>
        </div>

        {/* Setup panel layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
          
          {/* Main selection column (span 2) */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-serif text-[#c5a059] text-xs uppercase tracking-wider">Select Members</h3>
              
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-2.5 top-2 text-stone-600" size={12} />
                <input
                  type="text"
                  placeholder="Filter name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 border border-stone-800 rounded text-[11px] w-40 focus:outline-none focus:border-gold bg-[#121212] text-stone-200 placeholder-stone-600"
                />
              </div>
            </div>

            {players.length === 0 ? (
              <div className="p-8 border border-dashed border-stone-800 bg-[#0d0c0c]/40 rounded text-center space-y-3">
                <p className="text-xs text-stone-500">No players registered in the database.</p>
                <button
                  onClick={onNavigateToPlayers}
                  className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-gold bg-gold/5 hover:bg-gold/10 px-3 py-1.5 rounded transition-all border border-gold/10 cursor-pointer"
                >
                  <PlusCircle size={13} />
                  <span>Register Members Now</span>
                </button>
              </div>
            ) : (
              <div className="max-h-[350px] overflow-y-auto border border-stone-800 rounded bg-[#121212] divide-y divide-stone-900">
                {filteredPlayers.length === 0 ? (
                  <p className="p-4 text-xs text-stone-600 text-center">No matching players.</p>
                ) : (
                  filteredPlayers.map((player) => {
                    const isSelected = selectedIds.includes(player.id);
                    return (
                      <button
                        key={player.id}
                        onClick={() => togglePlayer(player.id)}
                        className={`w-full flex items-center justify-between p-3 text-left transition-colors cursor-pointer ${
                          isSelected ? 'bg-gold/5 hover:bg-gold/10' : 'hover:bg-stone-900/30'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded ${player.avatarColor} text-white flex items-center justify-center font-bold text-xs uppercase shadow-inner`}>
                            {player.name.charAt(0)}
                          </div>
                          <div>
                            <span className="font-semibold text-xs text-stone-200 block">{player.name}</span>
                            <span className="text-[9px] text-stone-500 font-mono block mt-0.5">
                              Win Rate: {player.gamesPlayed > 0 ? Math.round((player.gamesWon / player.gamesPlayed) * 100) : 0}% ({player.gamesWon} wins)
                            </span>
                          </div>
                        </div>

                        <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${
                          isSelected 
                            ? 'bg-gold border-gold text-black' 
                            : 'border-stone-800 text-transparent'
                        }`}>
                          <Check size={10} strokeWidth={3} />
                        </div>
                      </button>
                    );
                  })
                )}
              </div>
            )}
          </div>

          {/* Table preview column (span 1) */}
          <div className="bg-[#0c0a09] border border-stone-800 rounded-xl p-4 flex flex-col h-full justify-between">
            <div>
              <h3 className="font-serif text-gold text-[10px] uppercase tracking-[0.2em] mb-4 block">
                At The Table
              </h3>

              {selectedIds.length === 0 ? (
                <div className="py-12 text-center">
                  <p className="text-xs text-stone-600">No players seated</p>
                </div>
              ) : (
                <ul className="space-y-2 max-h-[250px] overflow-y-auto">
                  {players
                    .filter((p) => selectedIds.includes(p.id))
                    .map((player, index) => (
                      <motion.li
                        key={player.id}
                        initial={{ opacity: 0, x: 5 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex items-center justify-between bg-dark-card px-3 py-2 rounded border border-stone-900 shadow-sm"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-mono text-stone-600 w-4">{index + 1}.</span>
                          <div className={`w-5 h-5 rounded ${player.avatarColor} text-white flex items-center justify-center font-bold text-[9px] uppercase`}>
                            {player.name.charAt(0)}
                          </div>
                          <span className="text-xs font-medium text-stone-300 truncate max-w-[100px]">{player.name}</span>
                        </div>

                        <button
                          onClick={() => togglePlayer(player.id)}
                          className="text-[9px] uppercase text-stone-500 hover:text-red-400 font-bold transition-colors px-1 cursor-pointer"
                        >
                          Eject
                        </button>
                      </motion.li>
                    ))}
                </ul>
              )}
            </div>

            {/* Error notifications and Actions */}
            <div className="mt-6 pt-4 border-t border-stone-800/80 space-y-3">
              <AnimatePresence>
                {errorMsg && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-2.5 bg-red-950/15 border border-red-900/30 rounded text-red-400 text-xs flex items-start gap-1.5"
                  >
                    <AlertCircle className="shrink-0 mt-0.5 text-red-500" size={12} />
                    <span>{errorMsg}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              <button
                onClick={handleStart}
                disabled={isStarting || selectedIds.length < 2 || selectedIds.length > 9}
                className="w-full py-2.5 bg-gold hover:bg-gold-hover disabled:bg-stone-900 disabled:border-stone-850 disabled:text-stone-600 disabled:cursor-not-allowed border border-gold/10 text-black text-xs font-bold uppercase tracking-wider rounded transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                {isStarting ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                    <span>Dealing...</span>
                  </>
                ) : (
                  <>
                    <Play size={11} fill="currentColor" />
                    <span>Deal Rummy Cards ({selectedPlayersCount})</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
