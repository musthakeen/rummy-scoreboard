import { 
  collection, 
  getDocs, 
  addDoc, 
  updateDoc, 
  doc, 
  deleteDoc, 
  query, 
  orderBy, 
  limit,
  setDoc,
  getDoc
} from 'firebase/firestore';
import { db } from './firebase';
import { Player, Match, GameMode } from '../types';

const PLAYERS_COLLECTION = 'players';
const MATCHES_COLLECTION = 'matches';

const AVATAR_COLORS = [
  'bg-red-500', 'bg-blue-500', 'bg-green-500', 
  'bg-yellow-500', 'bg-purple-500', 'bg-pink-500', 
  'bg-indigo-500', 'bg-teal-500', 'bg-orange-500'
];

// Helper to get random color
function getRandomColor() {
  return AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];
}

export const dbService = {
  // --- PLAYER METHODS ---

  async getPlayers(): Promise<Player[]> {
    try {
      const q = query(collection(db, PLAYERS_COLLECTION), orderBy('name', 'asc'));
      const snapshot = await getDocs(q);
      const players: Player[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        players.push({
          id: doc.id,
          name: data.name || '',
          createdAt: data.createdAt || new Date().toISOString(),
          gamesPlayed: data.gamesPlayed || 0,
          gamesWon: data.gamesWon || 0,
          gamesLost: data.gamesLost || 0,
          avatarColor: data.avatarColor || 'bg-slate-500'
        });
      });
      return players;
    } catch (e) {
      console.error('Error getting players: ', e);
      return [];
    }
  },

  async addPlayer(name: string): Promise<Player | null> {
    try {
      const trimmedName = name.trim();
      if (!trimmedName) return null;

      const newPlayerData = {
        name: trimmedName,
        createdAt: new Date().toISOString(),
        gamesPlayed: 0,
        gamesWon: 0,
        gamesLost: 0,
        avatarColor: getRandomColor()
      };

      const docRef = await addDoc(collection(db, PLAYERS_COLLECTION), newPlayerData);
      return {
        id: docRef.id,
        ...newPlayerData
      };
    } catch (e) {
      console.error('Error adding player: ', e);
      return null;
    }
  },

  async deletePlayer(playerId: string): Promise<boolean> {
    try {
      await deleteDoc(doc(db, PLAYERS_COLLECTION, playerId));
      return true;
    } catch (e) {
      console.error('Error deleting player: ', e);
      return false;
    }
  },

  async updatePlayerStats(playerId: string, played: boolean, won: boolean, lost: boolean): Promise<void> {
    try {
      const playerRef = doc(db, PLAYERS_COLLECTION, playerId);
      const playerDoc = await getDoc(playerRef);
      if (playerDoc.exists()) {
        const data = playerDoc.data();
        const currentPlayed = data.gamesPlayed || 0;
        const currentWon = data.gamesWon || 0;
        const currentLost = data.gamesLost || 0;

        await updateDoc(playerRef, {
          gamesPlayed: currentPlayed + (played ? 1 : 0),
          gamesWon: currentWon + (won ? 1 : 0),
          gamesLost: currentLost + (lost ? 1 : 0)
        });
      }
    } catch (e) {
      console.error('Error updating player stats: ', e);
    }
  },

  // --- MATCH METHODS ---

  async getMatches(): Promise<Match[]> {
    try {
      const q = query(collection(db, MATCHES_COLLECTION), orderBy('date', 'desc'));
      const snapshot = await getDocs(q);
      const matches: Match[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        matches.push({
          id: doc.id,
          gameMode: data.gameMode || 'sevens',
          date: data.date || new Date().toISOString(),
          status: data.status || 'active',
          players: data.players || [],
          rounds: data.rounds || [],
          currentRound: data.currentRound || 0,
          winnerId: data.winnerId || null,
          loserId: data.loserId || null
        });
      });
      return matches;
    } catch (e) {
      console.error('Error getting matches: ', e);
      return [];
    }
  },

  async createMatch(gameMode: GameMode, players: Player[]): Promise<Match | null> {
    try {
      const matchPlayers = players.map(p => ({
        id: p.id,
        name: p.name,
        totalScore: 0
      }));

      // In Sevens, we start with 7 empty rounds
      // In Opens, we start with 1 empty round
      const initialRounds: Record<string, number>[] = [];
      const numRounds = gameMode === 'sevens' ? 7 : 1;
      
      for (let i = 0; i < numRounds; i++) {
        const roundMap: Record<string, number> = {};
        players.forEach(p => {
          roundMap[p.id] = 0; // default 0 or we can keep it as empty/undefined in UI
        });
        initialRounds.push(roundMap);
      }

      const newMatchData = {
        gameMode,
        date: new Date().toISOString(),
        status: 'active' as const,
        players: matchPlayers,
        rounds: initialRounds,
        currentRound: 0,
        winnerId: null,
        loserId: null
      };

      const docRef = await addDoc(collection(db, MATCHES_COLLECTION), newMatchData);
      return {
        id: docRef.id,
        ...newMatchData
      };
    } catch (e) {
      console.error('Error creating match: ', e);
      return null;
    }
  },

  async updateMatch(match: Match): Promise<boolean> {
    try {
      const { id, ...matchData } = match;
      await updateDoc(doc(db, MATCHES_COLLECTION, id), matchData);
      return true;
    } catch (e) {
      console.error('Error updating match: ', e);
      return false;
    }
  },

  async deleteMatch(matchId: string): Promise<boolean> {
    try {
      await deleteDoc(doc(db, MATCHES_COLLECTION, matchId));
      return true;
    } catch (e) {
      console.error('Error deleting match: ', e);
      return false;
    }
  },

  async resetAllData(): Promise<boolean> {
    try {
      // Delete all matches
      const matchesSnap = await getDocs(collection(db, MATCHES_COLLECTION));
      const deleteMatchPromises = matchesSnap.docs.map(doc => deleteDoc(doc.ref));
      await Promise.all(deleteMatchPromises);

      // Delete all players
      const playersSnap = await getDocs(collection(db, PLAYERS_COLLECTION));
      const deletePlayerPromises = playersSnap.docs.map(doc => deleteDoc(doc.ref));
      await Promise.all(deletePlayerPromises);

      return true;
    } catch (e) {
      console.error('Error resetting all data: ', e);
      return false;
    }
  }
};
