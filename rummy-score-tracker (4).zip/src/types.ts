export type GameMode = 'sevens' | 'opens';

export interface Player {
  id: string;
  name: string;
  createdAt: string;
  gamesPlayed: number;
  gamesWon: number;
  gamesLost: number; // For Sevens (highest point is loser) or Opens
  avatarColor: string;
}

export interface MatchPlayer {
  id: string;
  name: string;
  totalScore: number;
}

export interface Match {
  id: string;
  gameMode: GameMode;
  date: string;
  status: 'active' | 'completed';
  players: MatchPlayer[];
  rounds: Record<string, number>[]; // Array of maps: { [playerId]: score }
  currentRound: number; // 0-indexed, so 0 is Game 1/Round 1
  winnerId: string | null;
  loserId: string | null;
}
