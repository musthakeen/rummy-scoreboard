import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Trophy, Trash2, Eye, X, HelpCircle, ShieldAlert, FileText, Skull } from 'lucide-react';
import { Match, Player } from '../types';

interface MatchHistoryPageProps {
  matches: Match[];
  playersList: Player[];
  onDeleteMatch: (id: string) => Promise<void>;
}

export default function MatchHistoryPage({
  matches,
  playersList,
  onDeleteMatch
}: MatchHistoryPageProps) {
  const [filterMode, setFilterMode] = useState<'all' | 'sevens' | 'opens'>('all');
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [showConfirmDelete, setShowConfirmDelete] = useState<string | null>(null);

  // Filter completed matches
  const completedMatches = matches.filter(m => m.status === 'completed');

  const filteredMatches = completedMatches.filter((match) => {
    if (filterMode === 'all') return true;
    return match.gameMode === filterMode;
  });

  const getPlayerColor = (playerId: string) => {
    const player = playersList.find(p => p.id === playerId);
    return player ? player.avatarColor : 'bg-stone-600';
  };

  const getPlayerName = (playerId: string) => {
    return playersList.find(p => p.id === playerId)?.name || 'Unknown';
  };

  return (
    <div className="space-y-6" id="match-history-container">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-stone-800 pb-5">
        <div>
          <h1 className="text-2xl md:text-3xl font-serif text-[#c5a059] tracking-wider uppercase" id="history-title">Match History</h1>
          <p className="text-xs text-stone-500 mt-1">
            Browse through completed Sevens and Opens matches, review round-by-round points logs, and manage records.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex bg-[#121212] p-1 rounded border border-stone-800 w-fit shrink-0 self-start" id="history-filters">
          <button
            onClick={() => setFilterMode('all')}
            className={`px-4 py-1.5 rounded text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
              filterMode === 'all' ? 'bg-stone-800 text-gold font-bold shadow' : 'text-stone-500 hover:text-stone-300'
            }`}
          >
            All Mode
          </button>
          
          <button
            onClick={() => setFilterMode('sevens')}
            className={`px-4 py-1.5 rounded text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
              filterMode === 'sevens' ? 'bg-stone-800 text-gold font-bold shadow' : 'text-stone-500 hover:text-stone-300'
            }`}
          >
            Sevens
          </button>
          
          <button
            onClick={() => setFilterMode('opens')}
            className={`px-4 py-1.5 rounded text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
              filterMode === 'opens' ? 'bg-stone-800 text-gold font-bold shadow' : 'text-stone-500 hover:text-stone-300'
            }`}
          >
            Opens
          </button>
        </div>
      </div>

      {/* Matches List Grid */}
      <AnimatePresence mode="popLayout">
        {filteredMatches.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col items-center justify-center py-16 px-4 text-center border border-dashed border-stone-800 rounded-xl bg-dark-card/30"
            id="history-empty"
          >
            <div className="p-4 bg-[#1c1917] text-gold border border-stone-800 rounded mb-4">
              <Calendar size={24} />
            </div>
            <h3 className="font-serif text-stone-200 text-base">No matches found</h3>
            <p className="text-xs text-stone-500 mt-2 max-w-sm leading-relaxed">
              {filterMode === 'all' 
                ? 'Complete games at any of the active tables to write completed match certificates here.'
                : `No completed matches found under '${filterMode}' mode.`
              }
            </p>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="history-grid">
            {filteredMatches.map((match) => {
              const winner = match.players.find(p => p.id === match.winnerId);
              const loser = match.players.find(p => p.id === match.loserId);
              const dateObj = new Date(match.date);

              return (
                <motion.div
                  layout
                  key={match.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="bg-dark-card border border-stone-800 hover:border-stone-700 rounded-xl p-5 shadow-lg relative overflow-hidden transition-all group"
                  id={`history-card-${match.id}`}
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded bg-gold/10 text-gold border border-gold/20">
                        {match.gameMode}
                      </span>
                      <span className="text-xs font-serif font-semibold text-stone-300">
                        Table {match.id.slice(0, 6).toUpperCase()}
                      </span>
                    </div>

                    <div className="text-right text-[10px] text-stone-500 font-mono">
                      {dateObj.toLocaleDateString(undefined, { dateStyle: 'medium' })}
                    </div>
                  </div>

                  <p className="text-[10px] text-stone-500 leading-relaxed">
                    Finished at {dateObj.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })} with {match.players.length} participants.
                  </p>

                  {/* Summary of players score points */}
                  <div className="mt-4 pt-3 border-t border-stone-900 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-stone-500 text-[10px] uppercase tracking-wider font-semibold">End Game Standings:</span>
                    </div>

                    <div className="grid grid-cols-1 gap-2">
                      {winner && (
                        <div className="flex items-center justify-between bg-gold/5 text-gold border border-gold/10 px-3 py-1.5 rounded text-xs font-medium">
                          <div className="flex items-center gap-2 min-w-0">
                            <Trophy size={13} className="text-gold shrink-0" />
                            <span className="font-bold truncate">{winner.name}</span>
                          </div>
                          <span className="font-mono text-xs font-bold text-gold shrink-0">{winner.totalScore} pts (Champion)</span>
                        </div>
                      )}

                      {loser && (
                        <div className="flex items-center justify-between bg-red-950/15 text-red-400 border border-red-900/30 px-3 py-1.5 rounded text-xs font-medium">
                          <div className="flex items-center gap-2 min-w-0">
                            <Skull size={13} className="text-red-500 shrink-0" />
                            <span className="font-bold truncate">{loser.name}</span>
                          </div>
                          <span className="font-mono text-xs font-bold text-red-400 shrink-0">{loser.totalScore} pts (Loser)</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Quick stats on score range */}
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {match.players
                      .filter(p => p.id !== match.winnerId && p.id !== match.loserId)
                      .map(p => (
                        <span 
                          key={p.id}
                          className="bg-stone-900 border border-stone-850 text-stone-400 rounded px-2 py-0.5 text-[9px] font-mono"
                        >
                          {p.name}: <strong>{p.totalScore}</strong>
                        </span>
                      ))}
                  </div>

                  {/* Actions footer */}
                  <div className="mt-5 pt-3.5 border-t border-stone-900 flex items-center justify-between">
                    <button
                      onClick={() => setShowConfirmDelete(match.id)}
                      className="p-1.5 text-stone-600 hover:text-red-400 hover:bg-stone-900 rounded transition-colors cursor-pointer"
                      title="Delete match record"
                    >
                      <Trash2 size={14} />
                    </button>

                    <button
                      onClick={() => setSelectedMatch(match)}
                      className="px-3 py-1.5 bg-[#1c1917] hover:bg-stone-900 text-[#c5a059] border border-stone-800 text-xs font-bold uppercase tracking-wider rounded transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Eye size={12} />
                      <span>Scorecard Details</span>
                    </button>
                  </div>

                  {/* Delete Confirm Overlay */}
                  <AnimatePresence>
                    {showConfirmDelete === match.id && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 bg-[#0c0a09]/95 flex flex-col items-center justify-center p-4 text-center z-10"
                      >
                        <ShieldAlert className="text-red-500 mb-2" size={20} />
                        <h4 className="font-serif text-stone-200 text-xs uppercase tracking-wider">Delete archival log?</h4>
                        <p className="text-[10px] text-stone-500 mt-1 max-w-[200px] leading-relaxed">
                          This action is irreversible. Registered player profiles will not lose historical stats.
                        </p>
                        <div className="flex gap-2 mt-4">
                          <button
                            onClick={() => setShowConfirmDelete(null)}
                            className="px-3 py-1 bg-stone-900 border border-stone-800 text-stone-400 hover:text-white rounded text-xs transition-colors cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={async () => {
                              await onDeleteMatch(match.id);
                              setShowConfirmDelete(null);
                            }}
                            className="px-3 py-1 bg-red-950 text-red-300 border border-red-900 hover:bg-red-900 hover:text-white rounded text-xs transition-colors cursor-pointer"
                          >
                            Delete Log
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        )}
      </AnimatePresence>

      {/* Rounds Detail Modal */}
      <AnimatePresence>
        {selectedMatch && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-center p-4 md:p-6"
            onClick={() => setSelectedMatch(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-dark-card border border-stone-800 rounded-xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] text-stone-200"
              onClick={(e) => e.stopPropagation()} // Stop closing on inner click
            >
              {/* Modal Header */}
              <div className="p-5 border-b border-stone-800 flex items-center justify-between bg-[#121212]">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded bg-gold/10 text-gold border border-gold/20">
                      {selectedMatch.gameMode}
                    </span>
                    <h2 className="text-lg font-serif font-semibold text-[#c5a059] tracking-wider uppercase">
                      Table scorecard {selectedMatch.id.slice(0, 8).toUpperCase()}
                    </h2>
                  </div>
                  <p className="text-[10px] text-stone-500 font-mono mt-1">
                    Concluded {new Date(selectedMatch.date).toLocaleString()}
                  </p>
                </div>

                <button
                  onClick={() => setSelectedMatch(null)}
                  className="p-1.5 text-stone-500 hover:text-white rounded hover:bg-stone-800 transition-colors cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Modal Body with Scrollable Spreadsheet */}
              <div className="p-6 overflow-y-auto space-y-6">
                
                {/* Rankings ribbon */}
                <div className="flex flex-wrap gap-2.5">
                  {selectedMatch.players
                    .map(p => ({
                      ...p,
                      isWinner: p.id === selectedMatch.winnerId,
                      isLoser: p.id === selectedMatch.loserId,
                    }))
                    .sort((a, b) => a.totalScore - b.totalScore)
                    .map((p, index) => (
                      <div 
                        key={p.id}
                        className={`px-3 py-1.5 border rounded flex items-center gap-2 text-xs font-semibold ${
                          p.isWinner 
                            ? 'bg-gold/5 text-gold border-gold/20' 
                            : p.isLoser 
                            ? 'bg-red-950/15 text-red-400 border-red-900/30'
                            : 'bg-stone-900/40 text-stone-400 border-stone-850'
                        }`}
                      >
                        <div className={`w-5 h-5 rounded ${getPlayerColor(p.id)} text-white flex items-center justify-center font-bold text-[9px] uppercase shrink-0`}>
                          {p.name.charAt(0)}
                        </div>
                        <span>
                          {p.name}: <strong className="font-mono">{p.totalScore} pts</strong>
                        </span>
                        {p.isWinner && <span className="text-[10px]">🏆</span>}
                        {p.isLoser && <span className="text-[10px]">💀</span>}
                      </div>
                    ))}
                </div>

                {/* Score spreadsheet table */}
                <div className="border border-stone-800 rounded overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[#121212] border-b border-stone-800">
                          <th className="py-3 px-4 text-[10px] uppercase tracking-wider font-semibold text-stone-500 w-32">
                            Round Column
                          </th>
                          {selectedMatch.players.map((p) => (
                            <th key={p.id} className="py-3 px-3 text-xs font-semibold text-stone-200 text-center border-l border-stone-800">
                              <div className="flex items-center justify-center gap-1.5">
                                <span className={`w-5 h-5 rounded ${getPlayerColor(p.id)} text-white flex items-center justify-center font-bold text-[9px] uppercase`}>
                                  {p.name.charAt(0)}
                                </span>
                                <span className="truncate max-w-[80px]">{p.name}</span>
                              </div>
                            </th>
                          ))}
                        </tr>
                      </thead>

                      <tbody className="divide-y divide-stone-900 divide-x divide-stone-800/60">
                        {selectedMatch.rounds.map((round, rIndex) => (
                          <tr key={rIndex} className="hover:bg-stone-900/20">
                            <td className="py-2.5 px-4 font-semibold text-stone-400 text-xs">
                              Game {rIndex + 1}
                            </td>
                            {selectedMatch.players.map((p) => (
                              <td key={p.id} className="py-2.5 px-2 text-center text-xs font-bold text-stone-300 font-mono border-l border-stone-850">
                                {round[p.id] !== undefined ? round[p.id] : '-'}
                              </td>
                            ))}
                          </tr>
                        ))}

                        {/* Totals row */}
                        <tr className="bg-stone-900 font-bold border-t border-stone-800 divide-x divide-stone-800">
                          <td className="py-3 px-4 text-[10px] font-bold text-gold uppercase tracking-wider">
                            Final Total
                          </td>
                          {selectedMatch.players.map((p) => (
                            <td key={p.id} className="py-3 px-2 text-center text-xs font-mono font-extrabold text-gold bg-gold/5 border-l border-stone-800">
                              {p.totalScore}
                            </td>
                          ))}
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>

              {/* Modal Footer */}
              <div className="p-4 bg-[#121212] border-t border-stone-800 flex justify-end">
                <button
                  onClick={() => setSelectedMatch(null)}
                  className="px-4 py-2 bg-stone-900 border border-stone-800 hover:text-white text-stone-400 text-xs font-bold uppercase tracking-wider rounded transition-colors cursor-pointer"
                >
                  Close scorecard
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
