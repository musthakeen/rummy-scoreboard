import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Trash2, 
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  X, 
  Save, 
  ArrowLeft, 
  Info, 
  Undo,
  TrendingDown,
  Skull
} from 'lucide-react';
import { Match, Player, GameMode } from '../types';

interface MatchTableProps {
  match: Match;
  playersList: Player[]; // Full player directory
  onUpdateMatch: (match: Match) => Promise<void>;
  onFinishMatch: (match: Match, winnerId: string, loserId: string) => Promise<void>;
  onCancel: () => void;
}

export default function MatchTable({
  match,
  playersList,
  onUpdateMatch,
  onFinishMatch,
  onCancel
}: MatchTableProps) {
  // Local state for the editable rounds.
  const [rounds, setRounds] = useState<Record<string, number>[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [gameOverAlert, setGameOverAlert] = useState<string | null>(null);

  // Initialize rounds state when match changes
  useEffect(() => {
    if (match && match.rounds) {
      const copiedRounds = match.rounds.map(r => ({ ...r }));
      setRounds(copiedRounds);
    }
  }, [match]);

  // Map to easily access a player's avatarColor from the original directory list
  const getPlayerColor = (playerId: string) => {
    const player = playersList.find(p => p.id === playerId);
    return player ? player.avatarColor : 'bg-stone-600';
  };

  // Compute total scores for each player in real-time from the local rounds state
  const computeTotals = () => {
    const totals: Record<string, number> = {};
    match.players.forEach(p => {
      totals[p.id] = 0;
    });

    rounds.forEach(round => {
      match.players.forEach(p => {
        const score = Number(round[p.id]) || 0;
        totals[p.id] += score;
      });
    });

    return totals;
  };

  const totals = computeTotals();

  // Sort players for the live leaderboard: lowest score is first (winning), highest is last (losing)
  const getLeaderboard = () => {
    return [...match.players]
      .map(p => ({
        ...p,
        totalScore: totals[p.id] || 0
      }))
      .sort((a, b) => a.totalScore - b.totalScore);
  };

  const leaderboard = getLeaderboard();
  const currentLeader = leaderboard[0];
  const currentLoser = leaderboard[leaderboard.length - 1];

  // Detect Opens game over condition: score >= 320
  useEffect(() => {
    if (match.gameMode === 'opens' && match.status === 'active') {
      const reached320 = match.players.find(p => (totals[p.id] || 0) >= 320);
      if (reached320) {
        setGameOverAlert(
          `⚠️ Threshold crossed! ${reached320.name} has hit ${totals[reached320.id]} points (Opens ceiling is 320). Close this table and lock scores below.`
        );
      } else {
        setGameOverAlert(null);
      }
    }
  }, [totals, match.gameMode, match.players, match.status]);

  // Handle cell input changes
  const handleScoreChange = (roundIndex: number, playerId: string, value: string) => {
    const numericValue = value === '' ? 0 : Math.max(0, parseInt(value, 10) || 0);
    setRounds(prev => {
      const updated = [...prev];
      updated[roundIndex] = {
        ...updated[roundIndex],
        [playerId]: numericValue
      };
      return updated;
    });
  };

  // Add a new round (Only for Opens)
  const handleAddRound = () => {
    if (match.gameMode !== 'opens') return;
    const newRoundMap: Record<string, number> = {};
    match.players.forEach(p => {
      newRoundMap[p.id] = 0;
    });
    setRounds(prev => [...prev, newRoundMap]);
  };

  // Remove the last round (Only for Opens, if there are multiple rounds)
  const handleRemoveLastRound = () => {
    if (match.gameMode !== 'opens' || rounds.length <= 1) return;
    setRounds(prev => prev.slice(0, -1));
  };

  // Save changes to database (without finishing the match)
  const handleSaveDraft = async () => {
    setIsSaving(true);
    const updatedPlayers = match.players.map(p => ({
      ...p,
      totalScore: totals[p.id] || 0
    }));

    const updatedMatch: Match = {
      ...match,
      players: updatedPlayers,
      rounds: rounds,
    };

    try {
      await onUpdateMatch(updatedMatch);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSaving(false);
    }
  };

  // Finalize and conclude the entire match
  const handleFinalizeMatch = async () => {
    setIsSaving(true);
    const updatedPlayers = match.players.map(p => ({
      ...p,
      totalScore: totals[p.id] || 0
    }));

    // Re-calculate leader/loser to avoid stale closures
    const sorted = [...updatedPlayers].sort((a, b) => a.totalScore - b.totalScore);
    const winner = sorted[0];
    const loser = sorted[sorted.length - 1];

    const finalizedMatch: Match = {
      ...match,
      players: updatedPlayers,
      rounds: rounds,
      status: 'completed',
      winnerId: winner.id,
      loserId: loser.id,
    };

    try {
      await onFinishMatch(finalizedMatch, winner.id, loser.id);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto" id="match-table-root">
      
      {/* Header and Control Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-stone-850 pb-5">
        <div>
          <button
            onClick={onCancel}
            className="inline-flex items-center gap-1.5 text-stone-500 hover:text-stone-300 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer mb-2"
          >
            <ArrowLeft size={14} />
            <span>Back to Dashboard</span>
          </button>
          
          <div className="flex items-center gap-2">
            <h1 className="text-xl md:text-2xl font-serif text-[#c5a059] tracking-wider uppercase" id="table-header-title">
              Scoring Sheet <span className="text-stone-500 font-mono">#{match.id.slice(0, 8).toUpperCase()}</span>
            </h1>
            <span className={`px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest rounded border ${
              match.status === 'active' ? 'bg-gold/10 text-gold border-gold/25' : 'bg-stone-900 text-stone-500 border-stone-800'
            }`}>
              {match.status}
            </span>
          </div>
          <p className="text-[10px] text-stone-500 font-mono mt-1">
            Table configured {new Date(match.date).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}
          </p>
        </div>

        {/* Top Controls */}
        {match.status === 'active' && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveDraft}
              disabled={isSaving}
              className="px-3.5 py-2 border border-stone-800 hover:bg-stone-900 text-stone-300 hover:text-white rounded text-xs font-bold uppercase tracking-wider transition-all cursor-pointer"
              title="Save draft"
            >
              <Save size={13} className="inline mr-1" />
              <span>Save Draft</span>
            </button>

            <button
              onClick={handleFinalizeMatch}
              disabled={isSaving}
              className="px-4 py-2 bg-gold hover:bg-gold-hover text-black rounded text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <CheckCircle2 size={13} />
              <span>Lock & Archive Game</span>
            </button>
          </div>
        )}
      </div>

      {/* Warning Banners based on game rules */}
      <div className="space-y-3">
        {match.gameMode === 'sevens' && (
          <div className="p-4 bg-[#13110f] border border-gold/20 rounded text-gold/90 flex items-start gap-3 shadow-md">
            <Info className="text-gold shrink-0 mt-0.5" size={16} />
            <div className="text-xs leading-relaxed">
              <span className="font-serif font-bold text-sm uppercase tracking-wider text-gold block">Sevens Rummy protocol</span>
              <p className="mt-1 text-stone-400">
                Exactly <strong>7 games</strong> will be recorded. Game 7 is the final round. 
                <span className="text-gold font-medium"> The player who gets the highest cumulative points is the overall loser!</span> Keep scores low.
              </p>
            </div>
          </div>
        )}

        {match.gameMode === 'opens' && (
          <div className="p-4 bg-[#111314] border border-stone-800 rounded text-stone-300 flex items-start gap-3 shadow-md">
            <Info className="text-[#c5a059] shrink-0 mt-0.5" size={16} />
            <div className="text-xs leading-relaxed">
              <span className="font-serif font-bold text-sm uppercase tracking-wider text-[#c5a059] block">Opens Rummy protocol</span>
              <p className="mt-1 text-stone-400">
                Enter score sheet points round-by-round. When any participant hits or exceeds <strong>320 points</strong>, it is instant game over. The lowest score at that point wins.
              </p>
            </div>
          </div>
        )}

        {/* Live game-over alert for Opens */}
        <AnimatePresence>
          {gameOverAlert && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="p-4 bg-red-950/15 border border-red-900/30 rounded text-red-400 flex items-start gap-3 shadow-lg"
            >
              <AlertTriangle className="text-red-500 shrink-0 mt-0.5 animate-pulse" size={18} />
              <div className="text-xs">
                <span className="font-bold block text-sm text-red-300 uppercase tracking-wider">Ceiling Reached (320 Points limit)!</span>
                <p className="mt-1 text-stone-400 leading-relaxed">{gameOverAlert}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Grid: 1. Live Standings Leaderboard & 2. Scoring Spreadsheet */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Live Standings Leaderboard (1 Col on Desktop) */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-dark-card border border-stone-800 rounded-xl p-4 shadow-lg">
            <h3 className="font-serif text-gold text-[10px] uppercase tracking-[0.2em] mb-4 flex items-center justify-between border-b border-stone-900 pb-2">
              <span>Live Rank</span>
              <span className="text-[8px] text-stone-500 lowercase font-mono">lowest pts wins</span>
            </h3>

            <div className="space-y-2">
              {leaderboard.map((p, index) => {
                const isWinner = index === 0;
                const isLoser = index === leaderboard.length - 1;
                const scoreLimitDanger = match.gameMode === 'opens' && p.totalScore >= 300;

                return (
                  <div 
                    key={p.id}
                    className={`flex items-center justify-between p-2.5 rounded border transition-all ${
                      isWinner 
                        ? 'bg-gold/5 border-gold/15 text-gold' 
                        : isLoser 
                        ? 'bg-red-950/15 border-red-900/20 text-red-400'
                        : 'bg-stone-900/30 border-stone-850 text-stone-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[10px] font-bold text-stone-500 w-4">
                        {index === 0 ? '👑' : `#${index + 1}`}
                      </span>
                      <div className={`w-6 h-6 rounded ${getPlayerColor(p.id)} text-white flex items-center justify-center font-bold text-[10px] uppercase shrink-0`}>
                        {p.name.charAt(0)}
                      </div>
                      <span className="text-xs font-semibold truncate" title={p.name}>
                        {p.name}
                      </span>
                    </div>

                    <div className="text-right shrink-0">
                      <span className={`text-xs font-mono font-bold ${
                        scoreLimitDanger ? 'text-red-400 animate-pulse' : ''
                      }`}>
                        {p.totalScore}
                      </span>
                      {isWinner && (
                        <span className="text-[8px] uppercase tracking-wider text-gold block leading-tight mt-0.5">
                          Champion
                        </span>
                      )}
                      {isLoser && (
                        <span className="text-[8px] uppercase tracking-wider text-red-500 block leading-tight mt-0.5">
                          Danger
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick game status insights */}
          <div className="bg-[#0c0a09] border border-stone-800 rounded-xl p-4 text-xs space-y-2.5 text-stone-400 shadow-md">
            <h4 className="font-serif font-semibold text-gold uppercase tracking-wider text-[10px]">Table Stats</h4>
            <div className="flex justify-between py-1 border-b border-stone-900">
              <span className="text-stone-500">Current Leader:</span>
              <strong className="text-gold font-bold">{currentLeader?.name} ({totals[currentLeader?.id] || 0} pts)</strong>
            </div>
            <div className="flex justify-between py-1 border-b border-stone-900">
              <span className="text-stone-500">Highest Point:</span>
              <strong className="text-red-400 font-bold">{currentLoser?.name} ({totals[currentLoser?.id] || 0} pts)</strong>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-stone-500">Game Format:</span>
              <span className="font-semibold text-stone-300 capitalize">{match.gameMode}</span>
            </div>
          </div>
        </div>

        {/* Main Scoring Sheet / Spreadsheet (3 Cols on Desktop) */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-dark-card border border-stone-800 rounded-xl shadow-lg overflow-hidden">
            
            {/* Table Spreadsheet Wrapper */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse" id="scoring-table">
                <thead>
                  <tr className="bg-[#121212] border-b border-stone-800">
                    <th className="py-3.5 px-4 text-[10px] uppercase tracking-wider font-semibold text-stone-500 w-24">
                      Rounds List
                    </th>
                    {match.players.map((p) => (
                      <th key={p.id} className="py-3 px-3 text-xs font-semibold text-stone-200 text-center min-w-[100px] border-l border-stone-850">
                        <div className="flex flex-col items-center gap-1">
                          <div className={`w-7 h-7 rounded ${getPlayerColor(p.id)} text-white flex items-center justify-center font-bold text-xs uppercase shadow-inner`}>
                            {p.name.charAt(0)}
                          </div>
                          <span className="font-semibold text-xs text-stone-300 truncate max-w-[90px]" title={p.name}>
                            {p.name}
                          </span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody className="divide-y divide-stone-900">
                  {rounds.map((round, rIndex) => {
                    const isLastRoundSevens = match.gameMode === 'sevens' && rIndex === 6;

                    return (
                      <tr 
                        key={rIndex} 
                        className={`hover:bg-stone-900/20 transition-colors ${
                          isLastRoundSevens ? 'bg-amber-950/10 hover:bg-amber-950/20' : ''
                        }`}
                      >
                        <td className="py-3 px-4 font-semibold text-stone-400 text-xs">
                          {isLastRoundSevens ? (
                            <span className="flex items-center gap-1 font-bold text-gold">
                              <Skull size={11} />
                              Game 7 (Final)
                            </span>
                          ) : (
                            <span>Round {rIndex + 1}</span>
                          )}
                        </td>

                        {match.players.map((p) => (
                          <td key={p.id} className="py-2.5 px-2 text-center border-l border-stone-850">
                            <input
                              type="number"
                              inputMode="numeric"
                              pattern="[0-9]*"
                              min={0}
                              value={round[p.id] === undefined ? '' : round[p.id]}
                              onChange={(e) => handleScoreChange(rIndex, p.id, e.target.value)}
                              disabled={match.status !== 'active'}
                              className={`w-20 px-2 py-1.5 border rounded text-center font-mono font-bold text-xs focus:outline-none focus:border-gold transition-colors ${
                                match.status !== 'active' 
                                  ? 'bg-stone-900/60 text-stone-600 border-stone-850 cursor-not-allowed' 
                                  : isLastRoundSevens
                                  ? 'bg-[#121212] border-gold/30 text-gold focus:border-gold shadow-sm'
                                  : 'bg-[#121212] border-stone-800 text-stone-200 focus:border-gold'
                              }`}
                              placeholder="0"
                            />
                          </td>
                        ))}
                      </tr>
                    );
                  })}

                  {/* Running totals summation row */}
                  <tr className="bg-stone-900/50 font-bold border-t border-stone-800">
                    <td className="py-3.5 px-4 text-[10px] font-bold text-gold uppercase tracking-wider">
                      Cumulative
                    </td>
                    {match.players.map((p) => {
                      const limitDanger = match.gameMode === 'opens' && totals[p.id] >= 320;
                      return (
                        <td key={p.id} className="py-3 px-3 text-center text-xs font-mono font-bold border-l border-stone-800">
                          <span className={`px-2.5 py-1 rounded text-xs font-bold font-mono ${
                            limitDanger 
                              ? 'bg-red-900 text-red-100 border border-red-600 animate-pulse' 
                              : 'bg-gold/5 text-gold border border-gold/10'
                          }`}>
                            {totals[p.id] || 0}
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Bottom Actions for custom Round adding in Opens Mode */}
            {match.gameMode === 'opens' && match.status === 'active' && (
              <div className="p-4 bg-[#121212] border-t border-stone-800 flex items-center justify-between gap-2">
                <button
                  onClick={handleRemoveLastRound}
                  disabled={rounds.length <= 1}
                  className="px-3 py-1.5 border border-stone-800 hover:bg-red-950 hover:border-red-900 hover:text-red-400 disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:border-stone-800 disabled:hover:text-stone-500 rounded text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  title="Remove bottom-most round scorecard"
                >
                  <Undo size={12} className="inline mr-1" />
                  <span>Remove Round</span>
                </button>

                <button
                  onClick={handleAddRound}
                  className="px-3 py-1.5 bg-stone-900 border border-stone-800 text-gold hover:text-white rounded text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Plus size={13} />
                  <span>Add Score Row</span>
                </button>
              </div>
            )}
          </div>

          {/* Quick confirmation guidelines block */}
          <div className="bg-[#0c0a09] border border-stone-800 rounded-xl p-5 text-xs text-stone-500 space-y-2">
            <h4 className="font-serif font-bold text-stone-400 uppercase tracking-wider text-[10px]">Card-room Scorer Protocols</h4>
            <ul className="list-disc pl-4 space-y-1 text-stone-500 leading-relaxed">
              <li>Enter player scores in matching rounds. Draft is saved continuously by clicking <strong>Save Draft</strong>.</li>
              <li>Input positive numbers only. Enter 0 if a participant won the round.</li>
              <li>Once scores are locked and checked, click <strong>Lock & Archive Game</strong>. This registers outcomes securely to database profiles and updates directory ranks.</li>
            </ul>
          </div>
        </div>

      </div>
    </div>
  );
}
