import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, UserMinus, User, Trophy, Percent, Swords, ShieldAlert, Check } from 'lucide-react';
import { Player } from '../types';

interface PlayersPageProps {
  players: Player[];
  onAddPlayer: (name: string) => Promise<void>;
  onDeletePlayer: (id: string) => Promise<void>;
}

export default function PlayersPage({ players, onAddPlayer, onDeletePlayer }: PlayersPageProps) {
  const [name, setName] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setIsAdding(true);
    await onAddPlayer(name);
    setName('');
    setIsAdding(false);
  };

  return (
    <div className="space-y-8" id="players-page-container">
      {/* Header section with add player triggers */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-stone-800 pb-5">
        <div>
          <h1 className="text-2xl md:text-3xl font-serif text-[#c5a059] tracking-wider uppercase" id="players-title">Member Registry</h1>
          <p className="text-xs text-stone-500 mt-1" id="players-subtitle">
            Register and monitor club members. Up to 9 players can be placed at an active scoring table.
          </p>
        </div>

        {/* Quick Add Player Form */}
        <form onSubmit={handleSubmit} className="flex gap-2 max-w-md w-full md:w-auto" id="add-player-form">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name of player..."
            className="w-full md:w-64 px-4 py-2 border border-stone-800 rounded text-xs focus:outline-none focus:border-gold transition-colors bg-[#121212] text-stone-200 placeholder-stone-600"
            maxLength={15}
            required
            id="player-name-input"
          />
          <button
            type="submit"
            disabled={isAdding}
            className="px-4 py-2 bg-gold hover:bg-gold-hover text-black rounded text-xs font-bold tracking-wider uppercase transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap disabled:opacity-50 cursor-pointer"
            id="add-player-submit"
          >
            {isAdding ? (
              <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <Plus size={14} />
            )}
            <span>Register</span>
          </button>
        </form>
      </div>

      {/* Players List Grid */}
      <AnimatePresence mode="popLayout">
        {players.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col items-center justify-center py-16 px-4 text-center border border-dashed border-stone-800 rounded-xl bg-dark-card/30"
            id="players-empty-state"
          >
            <div className="p-4 bg-[#1c1917] text-gold border border-stone-800 rounded mb-4" id="players-empty-icon">
              <User size={24} />
            </div>
            <h3 className="font-serif text-stone-200 text-base">No registered members found</h3>
            <p className="text-xs text-stone-500 mt-2 max-w-sm leading-relaxed">
              Register players above to assemble custom tables for both Sevens and Opens formats.
            </p>
          </motion.div>
        ) : (
          <motion.div 
            layout
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
            id="players-grid"
          >
            {players.map((player) => {
              const winRate = player.gamesPlayed > 0 
                ? Math.round((player.gamesWon / player.gamesPlayed) * 100) 
                : 0;

              return (
                <motion.div
                  layout
                  key={player.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="bg-dark-card border border-stone-800 hover:border-stone-700 rounded-xl p-5 shadow-lg relative overflow-hidden transition-all group"
                  id={`player-card-${player.id}`}
                >
                  {/* Subtle top decoration */}
                  <div className={`absolute top-0 left-0 right-0 h-[3px] ${player.avatarColor}`} />

                  <div className="flex items-start gap-4">
                    {/* Avatar box */}
                    <div className={`w-12 h-12 rounded ${player.avatarColor} text-white flex items-center justify-center font-bold text-lg shadow-inner shrink-0 uppercase`}>
                      {player.name.charAt(0)}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-stone-200 truncate pr-6 text-sm" title={player.name}>
                          {player.name}
                        </h3>
                        
                        {/* Delete button (shows in card boundary) */}
                        <div className="absolute top-4 right-4">
                          <button
                            onClick={() => setShowConfirmDelete(player.id)}
                            className="text-stone-600 hover:text-red-400 p-1 rounded hover:bg-stone-900 transition-colors"
                            title="Remove player"
                            id={`delete-player-${player.id}`}
                          >
                            <UserMinus size={14} />
                          </button>
                        </div>
                      </div>
                      
                      <p className="text-[10px] text-stone-500 font-mono mt-1">
                        Registered {new Date(player.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                    </div>
                  </div>

                  {/* Stats Row */}
                  <div className="grid grid-cols-3 gap-2 mt-5 pt-4 border-t border-stone-900 text-center">
                    <div className="p-2 bg-[#0d0c0c] rounded border border-stone-900">
                      <span className="text-[9px] uppercase tracking-wider text-stone-500 block">Played</span>
                      <span className="text-xs font-bold text-stone-300 block mt-0.5">{player.gamesPlayed}</span>
                    </div>
                    <div className="p-2 bg-gold/5 rounded border border-gold/10">
                      <span className="text-[9px] uppercase tracking-wider text-gold block">Won</span>
                      <span className="text-xs font-bold text-gold block mt-0.5">{player.gamesWon}</span>
                    </div>
                    <div className="p-2 bg-[#1c1917] rounded border border-stone-800">
                      <span className="text-[9px] uppercase tracking-wider text-stone-400 block">Win Rate</span>
                      <span className="text-xs font-bold text-stone-300 block mt-0.5">{winRate}%</span>
                    </div>
                  </div>

                  {/* Delete Confirmation Overlay */}
                  <AnimatePresence>
                    {showConfirmDelete === player.id && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 bg-[#0c0a09]/95 flex flex-col items-center justify-center p-4 text-center z-10"
                      >
                        <ShieldAlert className="text-red-500 mb-2" size={20} />
                        <h4 className="font-serif text-stone-200 text-xs uppercase tracking-wider">Unregister {player.name}?</h4>
                        <p className="text-[10px] text-stone-500 mt-1 max-w-[200px] leading-relaxed">
                          Their stats directory and performance logs will be removed.
                        </p>
                        <div className="flex gap-2 mt-4">
                          <button
                            onClick={() => setShowConfirmDelete(null)}
                            className="px-3 py-1 bg-stone-900 border border-stone-800 text-stone-400 hover:text-white rounded text-xs transition-colors cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={async () => {
                              await onDeletePlayer(player.id);
                              setShowConfirmDelete(null);
                            }}
                            className="px-3 py-1 bg-red-950 text-red-300 border border-red-900 hover:bg-red-900 hover:text-white rounded text-xs transition-colors cursor-pointer"
                          >
                            Unregister
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
